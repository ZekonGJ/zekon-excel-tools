Attribute VB_Name = "ZekonBuilderB06"
Option Explicit

Public Sub ZEKON_BUDUJ_RC2C_B06()
    Dim selected As Variant, root As String, dest As String, output As String
    Dim wb As Workbook, parts As Object, part As Object, form As Object, designer As Object, ctl As Object
    Dim modules As Variant, item As Variant, test As Variant, f As Integer
    Dim oldEvents As Boolean, oldScreen As Boolean, created As Boolean, errorText As String
    Dim stage As String, sourceCode As String, openIndex As Long
    On Error GoTo Bad
    oldEvents = Application.EnableEvents: oldScreen = Application.ScreenUpdating
    If ThisWorkbook.IsAddin Then Err.Raise vbObjectError + 906, , "Zaimportuj instalator do pustego skoroszytu, nie do dodatku."
    MsgBox "Generator B06 - dodatek 1.0.0-rc2c" & vbCrLf & "Kod i logo sa zawarte w tym pliku. Zostanie utworzony osobny folder proby.", vbInformation, "ZEKON RC2 / B06"
    dest = Environ$("LOCALAPPDATA") & "\ZekonTools"
    If Dir$(dest, vbDirectory) = "" Then MkDir dest
    dest = dest & "\1.0.0-rc2c"
    If Dir$(dest, vbDirectory) = "" Then MkDir dest
    root = dest & "\B06_" & Format$(Now, "yyyymmdd_hhnnss")
    dest = root
    openIndex = 0
    Do While Len(Dir$(dest, vbDirectory)) > 0
        openIndex = openIndex + 1
        dest = root & "_" & CStr(openIndex)
    Loop
    MkDir dest
    output = dest & "\ZekonTools_1.0.0-rc2c.xlam"
    If Len(Dir$(output)) > 0 Then Err.Raise vbObjectError + 902, , "Dodatek juz istnieje. Nie nadpisano: " & output
    Application.EnableEvents = False: Application.ScreenUpdating = False
    ' Each release has a different filename; do not close the user's loaded add-in.
    stage = "Tworzenie skoroszytu i modulow"
    Set wb = Workbooks.Add(xlWBATWorksheet)
    Set parts = wb.VBProject.VBComponents
    modules = Array("modCore", "modRound", "modSplit", "modSearch", "modExport", "modSelfTest")
    For Each item In modules
        Set part = parts.Add(1)
        part.Name = CStr(item)
        sourceCode = EmbeddedSource(CStr(item))
        If CStr(item) = "modCore" Then sourceCode = Replace(sourceCode, "1.0.0-rc1a", "1.0.0-rc2c")
        If CStr(item) = "modCore" Then sourceCode = Replace(sourceCode, "1.0.0-rc1b", "1.0.0-rc2c")
        part.CodeModule.AddFromString sourceCode
    Next item
    stage = "Tworzenie panelu"
    Set form = parts.Add(3)
    form.Name = "frmZekon"
    form.Properties("Caption") = "Narzedzia ZEKON"
    form.Properties("Width") = 820
    form.Properties("Height") = 618
    form.Properties("BackColor") = 16118774
    form.Properties("StartUpPosition") = 1
    Set designer = form.Designer
    BuildControls designer
    form.CodeModule.AddFromString EmbeddedSource("frmZekon")
    parts(wb.CodeName).CodeModule.AddFromString EmbeddedSource("ThisWorkbook")
    stage = "Kopiowanie logo"
    WriteEmbeddedLogo dest & "\logo.bmp"
    wb.BuiltinDocumentProperties("Title") = "Narzedzia ZEKON 1.0.0-rc2c"
    wb.IsAddin = True
    stage = "Zapis XLAM"
    wb.SaveAs Filename:=output, FileFormat:=55
    created = True
    stage = "Kontrola zapisanego pliku"
    If Len(Dir$(output)) = 0 Then Err.Raise vbObjectError + 904, , "Brak pliku po SaveAs: " & output
    ' Zapis XLAM moze pozostawic wb jako skoroszyt roboczy, np. Arkusz2.
    ' Testy uruchamiamy z projektu otwartego ponownie z rzeczywistego pliku.
    stage = "Zamkniecie skoroszytu roboczego"
    Set ctl = Nothing
    Set designer = Nothing
    Set form = Nothing
    Set part = Nothing
    Set parts = Nothing
    wb.Close SaveChanges:=False
    Set wb = Nothing
    stage = "Otwarcie zapisanego dodatku"
    Set wb = Application.Workbooks.Open(Filename:=output, UpdateLinks:=0, ReadOnly:=False)
    If StrComp(wb.FullName, output, vbTextCompare) <> 0 Then Err.Raise vbObjectError + 905, , "Otwarty plik ma inna sciezke: " & wb.FullName
    stage = "Uruchomienie testow Excel"
    test = Application.Run("'" & Replace(wb.FullName, "'", "''") & "'!modSelfTest.ZekonSelfTest")
    If Left$(CStr(test), 5) <> "PASS:" Then Err.Raise vbObjectError + 903, , "Test dodatku nie zakonczyl sie PASS."
    stage = "Zapis wyniku testow"
    f = FreeFile
    Open dest & "\test-result.txt" For Output As #f
    Print #f, Format$(Now, "yyyy-mm-dd hh:nn:ss")
    Print #f, CStr(test)
    Close #f: f = 0
    wb.Save
    wb.Close SaveChanges:=False
    Set wb = Nothing
    Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen
    MsgBox "DODATEK UTWORZONY. Testy funkcjonalne: PASS." & vbCrLf & output & vbCrLf & "Przeslij plik XLAM oraz test-result.txt z otwartego folderu." & vbCrLf & "Wylacz ponownie dostep do modelu obiektowego projektu VBA.", vbInformation, "ZEKON"
    Shell "explorer.exe """ & dest & """", vbNormalFocus
    Exit Sub
Bad:
    errorText = "Etap: " & stage & vbCrLf & "Blad " & Err.Number & ": " & Err.Description & vbCrLf & "Plik docelowy: " & output
    On Error Resume Next
    If f > 0 Then Close #f
    If Not wb Is Nothing Then wb.Close SaveChanges:=False
    If created Then Name output As dest & "\FAILED_" & Format$(Now, "yyyymmdd_hhnnss") & ".xlam"
    Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen
    On Error GoTo 0
    MsgBox "Nie zakonczono budowania: " & errorText & vbCrLf & "Nie wlaczaj nieprzetestowanego pliku. Zachowaj ten komunikat diagnostyczny.", vbExclamation, "ZEKON RC2 / B06"
End Sub

Private Function ReadUtf8(ByVal path As String) As String
    Dim stream As Object
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 2: stream.Charset = "utf-8"
    stream.Open
    stream.LoadFromFile path
    ReadUtf8 = stream.ReadText
    stream.Close
End Function

Private Sub BuildControls(ByVal designer As Object)
    Dim ctl As Object

    Set ctl = designer.Controls.Add("Forms.Label.1", "side", True)
    ctl.Left = 0
    ctl.Top = 0
    ctl.Width = 184
    ctl.Height = 598
    ctl.Caption = ""
    ctl.ForeColor = 3877920
    ctl.BackStyle = 1
    ctl.BackColor = 3680798
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "logoBg", True)
    ctl.Left = 16
    ctl.Top = 18
    ctl.Width = 152
    ctl.Height = 99
    ctl.Caption = ""
    ctl.ForeColor = 3877920
    ctl.BackStyle = 1
    ctl.BackColor = 16777215
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Image.1", "imgLogo", True)
    ctl.Left = 24
    ctl.Top = 23
    ctl.Width = 136
    ctl.Height = 84
    ctl.BackColor = 16777215
    ctl.BorderStyle = 0
    ctl.PictureSizeMode = 3
    Set ctl = designer.Controls.Add("Forms.Label.1", "sideTitle", True)
    ctl.Left = 20
    ctl.Top = 136
    ctl.Width = 145
    ctl.Height = 24
    ctl.Caption = "NARZEDZIA ZEKON"
    ctl.ForeColor = 16777215
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    ctl.Font.Bold = True
    Set ctl = designer.Controls.Add("Forms.Label.1", "sideSub", True)
    ctl.Left = 20
    ctl.Top = 157
    ctl.Width = 146
    ctl.Height = 30
    ctl.Caption = "Twoj warsztat w Excelu"
    ctl.ForeColor = 13022889
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "nav1", True)
    ctl.Left = 12
    ctl.Top = 201
    ctl.Width = 160
    ctl.Height = 33
    ctl.Caption = "Zaokraglanie"
    ctl.BackColor = 3680798
    ctl.ForeColor = 16777215
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "nav2", True)
    ctl.Left = 12
    ctl.Top = 240
    ctl.Width = 160
    ctl.Height = 33
    ctl.Caption = "Wyszukiwanie pozycji"
    ctl.BackColor = 3680798
    ctl.ForeColor = 16777215
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "nav3", True)
    ctl.Left = 12
    ctl.Top = 279
    ctl.Width = 160
    ctl.Height = 33
    ctl.Caption = "Rozbijanie na sztuki"
    ctl.BackColor = 3680798
    ctl.ForeColor = 16777215
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "nav4", True)
    ctl.Left = 12
    ctl.Top = 318
    ctl.Width = 160
    ctl.Height = 33
    ctl.Caption = "Eksport: malowanie"
    ctl.BackColor = 3680798
    ctl.ForeColor = 16777215
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "nav5", True)
    ctl.Left = 12
    ctl.Top = 357
    ctl.Width = 160
    ctl.Height = 33
    ctl.Caption = "Eksport: ocynk"
    ctl.BackColor = 3680798
    ctl.ForeColor = 16777215
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "nav6", True)
    ctl.Left = 12
    ctl.Top = 396
    ctl.Width = 160
    ctl.Height = 33
    ctl.Caption = "Sztuki + malowanie"
    ctl.BackColor = 3680798
    ctl.ForeColor = 16777215
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "nav7", True)
    ctl.Left = 12
    ctl.Top = 435
    ctl.Width = 160
    ctl.Height = 33
    ctl.Caption = "Sztuki + ocynk"
    ctl.BackColor = 3680798
    ctl.ForeColor = 16777215
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "version", True)
    ctl.Left = 20
    ctl.Top = 530
    ctl.Width = 155
    ctl.Height = 30
    ctl.Caption = "Wersja dodatku"
    ctl.ForeColor = 13022889
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblTitle", True)
    ctl.Left = 208
    ctl.Top = 20
    ctl.Width = 570
    ctl.Height = 28
    ctl.Caption = "Zaokraglanie"
    ctl.ForeColor = 3877920
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 20
    ctl.Font.Bold = True
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblDetail", True)
    ctl.Left = 208
    ctl.Top = 56
    ctl.Width = 570
    ctl.Height = 37
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "bookLabel", True)
    ctl.Left = 208
    ctl.Top = 100
    ctl.Width = 274
    ctl.Height = 16
    ctl.Caption = "SKOROSZYT"
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    ctl.Font.Bold = True
    Set ctl = designer.Controls.Add("Forms.Label.1", "sheetLabel", True)
    ctl.Left = 500
    ctl.Top = 100
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = "ARKUSZ"
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    ctl.Font.Bold = True
    Set ctl = designer.Controls.Add("Forms.ComboBox.1", "cboBook", True)
    ctl.Left = 208
    ctl.Top = 119
    ctl.Width = 276
    ctl.Height = 25
    ctl.Style = 2
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.ComboBox.1", "cboSheet", True)
    ctl.Left = 500
    ctl.Top = 119
    ctl.Width = 276
    ctl.Height = 25
    ctl.Style = 2
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "firstLabel", True)
    ctl.Left = 208
    ctl.Top = 158
    ctl.Width = 180
    ctl.Height = 17
    ctl.Caption = "Poczatek: AUTO lub wiersz"
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtFirst", True)
    ctl.Left = 208
    ctl.Top = 178
    ctl.Width = 100
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CheckBox.1", "chkVisible", True)
    ctl.Left = 329
    ctl.Top = 177
    ctl.Width = 203
    ctl.Height = 25
    ctl.Caption = "Tylko widoczne wiersze"
    ctl.BackStyle = 0
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CheckBox.1", "chkCopy", True)
    ctl.Left = 535
    ctl.Top = 177
    ctl.Width = 245
    ctl.Height = 25
    ctl.Caption = "Pracuj na kopii skoroszytu"
    ctl.BackStyle = 0
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP1", True)
    ctl.Left = 208
    ctl.Top = 220
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP1", True)
    ctl.Left = 208
    ctl.Top = 237
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP2", True)
    ctl.Left = 500
    ctl.Top = 220
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP2", True)
    ctl.Left = 500
    ctl.Top = 237
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP3", True)
    ctl.Left = 208
    ctl.Top = 266
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP3", True)
    ctl.Left = 208
    ctl.Top = 283
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP4", True)
    ctl.Left = 500
    ctl.Top = 266
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP4", True)
    ctl.Left = 500
    ctl.Top = 283
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP5", True)
    ctl.Left = 208
    ctl.Top = 312
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP5", True)
    ctl.Left = 208
    ctl.Top = 329
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP6", True)
    ctl.Left = 500
    ctl.Top = 312
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP6", True)
    ctl.Left = 500
    ctl.Top = 329
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP7", True)
    ctl.Left = 208
    ctl.Top = 358
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP7", True)
    ctl.Left = 208
    ctl.Top = 375
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP8", True)
    ctl.Left = 500
    ctl.Top = 358
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP8", True)
    ctl.Left = 500
    ctl.Top = 375
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP9", True)
    ctl.Left = 208
    ctl.Top = 404
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP9", True)
    ctl.Left = 208
    ctl.Top = 421
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblP10", True)
    ctl.Left = 500
    ctl.Top = 404
    ctl.Width = 276
    ctl.Height = 16
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtP10", True)
    ctl.Left = 500
    ctl.Top = 421
    ctl.Width = 276
    ctl.Height = 24
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CheckBox.1", "chkFormulas", True)
    ctl.Left = 208
    ctl.Top = 275
    ctl.Width = 570
    ctl.Height = 23
    ctl.Caption = "Zastap rowniez formuly wartosciami (nieodwracalne)"
    ctl.BackStyle = 0
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "profileLabel", True)
    ctl.Left = 208
    ctl.Top = 462
    ctl.Width = 165
    ctl.Height = 16
    ctl.Caption = "PROFIL USTAWIEN"
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    ctl.Font.Bold = True
    Set ctl = designer.Controls.Add("Forms.TextBox.1", "txtProfile", True)
    ctl.Left = 208
    ctl.Top = 481
    ctl.Width = 230
    ctl.Height = 25
    ctl.SpecialEffect = 0
    ctl.BorderStyle = 1
    ctl.BorderColor = 14669261
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "cmdLoad", True)
    ctl.Left = 452
    ctl.Top = 481
    ctl.Width = 108
    ctl.Height = 25
    ctl.Caption = "Wczytaj"
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "cmdSave", True)
    ctl.Left = 570
    ctl.Top = 481
    ctl.Width = 108
    ctl.Height = 25
    ctl.Caption = "Zapisz profil"
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "lblStatus", True)
    ctl.Left = 208
    ctl.Top = 516
    ctl.Width = 570
    ctl.Height = 19
    ctl.Caption = ""
    ctl.ForeColor = 8679523
    ctl.BackStyle = 0
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "cmdClose", True)
    ctl.Left = 208
    ctl.Top = 543
    ctl.Width = 115
    ctl.Height = 28
    ctl.Caption = "Zamknij"
    ctl.BackColor = 16777215
    ctl.ForeColor = 3877920
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.CommandButton.1", "cmdRun", True)
    ctl.Left = 589
    ctl.Top = 539
    ctl.Width = 187
    ctl.Height = 34
    ctl.Caption = "Uruchom operacje"
    ctl.BackColor = 2957501
    ctl.ForeColor = 16777215
    ctl.TakeFocusOnClick = True
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 10
    Set ctl = designer.Controls.Add("Forms.Label.1", "progressTrack", True)
    ctl.Left = 208
    ctl.Top = 535
    ctl.Width = 568
    ctl.Height = 3
    ctl.Caption = ""
    ctl.BackStyle = 1
    ctl.BackColor = 14669261
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
    Set ctl = designer.Controls.Add("Forms.Label.1", "progressFill", True)
    ctl.Left = 208
    ctl.Top = 535
    ctl.Width = 0
    ctl.Height = 3
    ctl.Caption = ""
    ctl.BackStyle = 1
    ctl.BackColor = 2957501
    ctl.Font.Name = "Segoe UI"
    ctl.Font.Size = 9
End Sub
Private Function EmbeddedSource(ByVal moduleName As String) As String
    Select Case moduleName
        Case "ThisWorkbook"
            EmbeddedSource = EmbeddedSource & Source_ThisWorkbook_0()
        Case "frmZekon"
            EmbeddedSource = EmbeddedSource & Source_frmZekon_0()
            EmbeddedSource = EmbeddedSource & Source_frmZekon_1()
            EmbeddedSource = EmbeddedSource & Source_frmZekon_2()
            EmbeddedSource = EmbeddedSource & Source_frmZekon_3()
            EmbeddedSource = EmbeddedSource & Source_frmZekon_4()
            EmbeddedSource = EmbeddedSource & Source_frmZekon_5()
            EmbeddedSource = EmbeddedSource & Source_frmZekon_6()
            EmbeddedSource = EmbeddedSource & Source_frmZekon_7()
        Case "modCore"
            EmbeddedSource = EmbeddedSource & Source_modCore_0()
            EmbeddedSource = EmbeddedSource & Source_modCore_1()
            EmbeddedSource = EmbeddedSource & Source_modCore_2()
            EmbeddedSource = EmbeddedSource & Source_modCore_3()
            EmbeddedSource = EmbeddedSource & Source_modCore_4()
            EmbeddedSource = EmbeddedSource & Source_modCore_5()
            EmbeddedSource = EmbeddedSource & Source_modCore_6()
            EmbeddedSource = EmbeddedSource & Source_modCore_7()
        Case "modExport"
            EmbeddedSource = EmbeddedSource & Source_modExport_0()
            EmbeddedSource = EmbeddedSource & Source_modExport_1()
        Case "modRound"
            EmbeddedSource = EmbeddedSource & Source_modRound_0()
            EmbeddedSource = EmbeddedSource & Source_modRound_1()
        Case "modSearch"
            EmbeddedSource = EmbeddedSource & Source_modSearch_0()
            EmbeddedSource = EmbeddedSource & Source_modSearch_1()
            EmbeddedSource = EmbeddedSource & Source_modSearch_2()
            EmbeddedSource = EmbeddedSource & Source_modSearch_3()
            EmbeddedSource = EmbeddedSource & Source_modSearch_4()
        Case "modSelfTest"
            EmbeddedSource = EmbeddedSource & Source_modSelfTest_0()
            EmbeddedSource = EmbeddedSource & Source_modSelfTest_1()
            EmbeddedSource = EmbeddedSource & Source_modSelfTest_2()
            EmbeddedSource = EmbeddedSource & Source_modSelfTest_3()
            EmbeddedSource = EmbeddedSource & Source_modSelfTest_4()
            EmbeddedSource = EmbeddedSource & Source_modSelfTest_5()
        Case "modSplit"
            EmbeddedSource = EmbeddedSource & Source_modSplit_0()
            EmbeddedSource = EmbeddedSource & Source_modSplit_1()
            EmbeddedSource = EmbeddedSource & Source_modSplit_2()
            EmbeddedSource = EmbeddedSource & Source_modSplit_3()
        Case Else: Err.Raise vbObjectError + 908, , "Nieznany modul instalatora"
    End Select
End Function

Private Function Source_ThisWorkbook_0() As String
    Dim s As String
    s = s & "Option Explicit" & vbCrLf
    s = s & "Private Sub Workbook_Open()" & vbCrLf
    s = s & "    InstallMenu" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub Workbook_AddinInstall()" & vbCrLf
    s = s & "    InstallMenu" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub Workbook_AddinUninstall()" & vbCrLf
    s = s & "    Auto_Close" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub Workbook_BeforeClose(Cancel As Boolean)" & vbCrLf
    s = s & "    Auto_Close" & vbCrLf
    s = s & "End Sub" & vbCrLf
    Source_ThisWorkbook_0 = s
End Function

Private Function Source_frmZekon_0() As String
    Dim s As String
    s = s & "Option Explicit" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private mode As Long" & vbCrLf
    s = s & "Private busy As Boolean" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub UserForm_Initialize()" & vbCrLf
    s = s & "    Dim wb As Workbook" & vbCrLf
    s = s & "    Me.Caption = ""Narzedzia ZEKON | "" & APP_VERSION" & vbCrLf
    s = s & "    Me.Controls(""version"").Caption = ""Wersja: "" & APP_VERSION" & vbCrLf
    s = s & "    imgLogo.Picture = LoadPicture(ThisWorkbook.Path & ""\logo.bmp"")" & vbCrLf
    s = s & "    For Each wb In Application.Workbooks" & vbCrLf
    s = s & "        If Not wb.IsAddin And wb.Name <> ThisWorkbook.Name Then cboBook.AddItem wb.Name" & vbCrLf
    s = s & "    Next wb" & vbCrLf
    s = s & "    If cboBook.ListCount > 0 Then" & vbCrLf
    s = s & "        cboBook.ListIndex = 0" & vbCrLf
    s = s & "        On Error Resume Next" & vbCrLf
    s = s & "        cboBook.Value = Application.ActiveWorkbook.Name" & vbCrLf
    s = s & "        cboSheet.Value = Application.ActiveSheet.Name" & vbCrLf
    s = s & "        On Error GoTo 0" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    txtProfile.Text = ""Domyslny""" & vbCrLf
    s = s & "    chkCopy.Value = True" & vbCrLf
    s = s & "    SelectMode 1" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub cboBook_Change()" & vbCrLf
    s = s & "    Dim ws As Worksheet, wb As Workbook" & vbCrLf
    s = s & "    cboSheet.Clear" & vbCrLf
    s = s & "    If cboBook.ListIndex < 0 Then Exit Sub" & vbCrLf
    s = s & "    Set wb = Application.Workbooks(CStr(cboBook.Value))" & vbCrLf
    s = s & "    For Each ws In wb.Worksheets" & vbCrLf
    s = s & "        cboSheet.AddItem ws.Name" & vbCrLf
    s = s & "    Next ws" & vbCrLf
    s = s & "    If cboSheet.ListCount > 0 Then cboSheet.ListIndex = 0" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub SelectMode(ByVal selected As Long)" & vbCrLf
    s = s & "    Dim labels As Variant, defaults As Variant, i As Long, title As String, detail As String" & vbCrLf
    s = s & "    If busy Then Exit Sub" & vbCrLf
    s = s & "    mode = selected" & vbCrLf
    Source_frmZekon_0 = s
End Function

Private Function Source_frmZekon_1() As String
    Dim s As String
    s = s & "    chkFormulas.Visible = (mode = 1)" & vbCrLf
    s = s & "    chkCopy.Enabled = (mode <> 4 And mode <> 5)" & vbCrLf
    s = s & "    labels = Array(): defaults = Array()" & vbCrLf
    s = s & "    Select Case mode" & vbCrLf
    s = s & "        Case 1" & vbCrLf
    s = s & "            title = ""Zaokraglanie""" & vbCrLf
    s = s & "            detail = ""Zaokraglij wartosci do liczb calkowitych. Formuly domyslnie pozostaja bez zmian.""" & vbCrLf
    s = s & "            labels = Array(""Kolumna do zaokraglenia"")" & vbCrLf
    s = s & "            defaults = Array(""F"")" & vbCrLf
    s = s & "        Case 2" & vbCrLf
    s = s & "            title = ""Wyszukiwanie pozycji""" & vbCrLf
    s = s & "            detail = ""Filtruj zestawienie wedlug listy. Braki otrzymaja czerwone oznaczenie i osobny raport.""" & vbCrLf
    s = s & "            labels = Array(""Kolumna listy pozycji"", ""Arkusz zestawienia"", ""Kolumna pozycji w zestawieniu"", ""Poczatek zestawienia (AUTO lub wiersz)"")" & vbCrLf
    s = s & "            defaults = Array(""A"", ""bt-list"", ""B"", ""AUTO"")" & vbCrLf
    s = s & "        Case 3" & vbCrLf
    s = s & "            title = ""Rozbijanie na sztuki""" & vbCrLf
    s = s & "            detail = ""Powiel wiersze wedlug ilosci, ustaw ilosc = 1 i nadaj numery sztuk od 1.""" & vbCrLf
    s = s & "            labels = Array(""Kolumna ilosci"", ""Kolumna numeru sztuki"")" & vbCrLf
    s = s & "            defaults = Array(""E"", ""C"")" & vbCrLf
    s = s & "        Case 4, 5, 6, 7" & vbCrLf
    s = s & "            If mode = 4 Or mode = 6 Then title = ""Eksport: malowanie"" Else title = ""Eksport: ocynk""" & vbCrLf
    s = s & "            detail = ""Ustaw mapowanie kolumn. Dlugosc wymaga wskazania. Eksport pomija puste pozycje.""" & vbCrLf
    s = s & "            labels = Array(""Nazwa kontraktu"", ""Kolumna nr kontraktu"", ""Kolumna pozycji"", ""Kolumna profilu"", ""Kolumna dlugosci"", ""Kolumna wagi"", ""Kolumna numeru sztuki"", ""Pierwszy wiersz eksportu"")" & vbCrLf
    s = s & "            If mode = 4 Or mode = 6 Then" & vbCrLf
    s = s & "                defaults = Array("""", ""B"", ""D"", ""M"", """", ""F"", ""C"", ""3"")" & vbCrLf
    s = s & "            Else" & vbCrLf
    s = s & "                defaults = Array("""", ""B"", ""D"", ""M"", """", ""F"", ""C"", ""2"")" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "            If mode >= 6 Then" & vbCrLf
    s = s & "                title = ""Sekwencja: sztuki + "" & IIf(mode = 6, ""malowanie"", ""ocynk"")" & vbCrLf
    s = s & "                detail = ""Najpierw rozbij ilosci; potem eksportuj z tego samego arkusza. Numer sztuki: kolumna z pola 7.""" & vbCrLf
    s = s & "                labels = Array(""Nazwa kontraktu"", ""Kolumna nr kontraktu"", ""Kolumna pozycji"", ""Kolumna profilu"", ""Kolumna dlugosci"", ""Kolumna wagi"", ""Kolumna numeru sztuki"", ""Pierwszy wiersz eksportu"", ""Kolumna ilosci do rozbicia"")" & vbCrLf
    s = s & "                If mode = 6 Then defaults = Array("""", ""B"", ""D"", ""M"", """", ""F"", ""C"", ""3"", ""E"")" & vbCrLf
    s = s & "                If mode = 7 Then defaults = Array("""", ""B"", ""D"", ""M"", """", ""F"", ""C"", ""2"", ""E"")" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "    End Select" & vbCrLf
    s = s & "    lblTitle.Caption = title" & vbCrLf
    s = s & "    lblDetail.Caption = detail" & vbCrLf
    s = s & "    For i = 1 To 10" & vbCrLf
    s = s & "        Me.Controls(""lblP"" & i).Visible = (i <= UBound(labels) + 1)" & vbCrLf
    Source_frmZekon_1 = s
End Function

Private Function Source_frmZekon_2() As String
    Dim s As String
    s = s & "        Me.Controls(""txtP"" & i).Visible = (i <= UBound(labels) + 1)" & vbCrLf
    s = s & "        Me.Controls(""txtP"" & i).Text = """"" & vbCrLf
    s = s & "        If i <= UBound(labels) + 1 Then" & vbCrLf
    s = s & "            Me.Controls(""lblP"" & i).Caption = labels(i - 1)" & vbCrLf
    s = s & "            Me.Controls(""txtP"" & i).Text = defaults(i - 1)" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    txtFirst.Text = ""AUTO""" & vbCrLf
    s = s & "    chkVisible.Value = True" & vbCrLf
    s = s & "    chkFormulas.Value = False" & vbCrLf
    s = s & "    LoadProfile" & vbCrLf
    s = s & "    For i = 1 To 7" & vbCrLf
    s = s & "        Me.Controls(""nav"" & i).BackColor = RGB(30, 42, 56)" & vbCrLf
    s = s & "        If i = mode Then Me.Controls(""nav"" & i).BackColor = RGB(189, 32, 45)" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    lblStatus.Caption = ""Wybierz dane, sprawdz ustawienia i uruchom operacje.""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Function SectionName() As String" & vbCrLf
    s = s & "    Dim s As String" & vbCrLf
    s = s & "    s = Trim$(txtProfile.Text)" & vbCrLf
    s = s & "    If Len(s) = 0 Then Fail ""Wpisz nazwe profilu ustawien.""" & vbCrLf
    s = s & "    If Len(s) > 60 Or InStr(s, ""\"") > 0 Then Fail ""Niepoprawna nazwa profilu.""" & vbCrLf
    s = s & "    SectionName = ""Profil_"" & s & ""_"" & mode" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub LoadProfile()" & vbCrLf
    s = s & "    Dim section As String, i As Long" & vbCrLf
    s = s & "    section = SectionName()" & vbCrLf
    s = s & "    For i = 1 To 10" & vbCrLf
    s = s & "        Me.Controls(""txtP"" & i).Text = GetSetting(APP_ID, section, ""p"" & i, Me.Controls(""txtP"" & i).Text)" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    txtFirst.Text = GetSetting(APP_ID, section, ""first_auto"", ""AUTO"")" & vbCrLf
    s = s & "    If mode = 2 Then txtP4.Text = GetSetting(APP_ID, section, ""target_first_auto"", ""AUTO"")" & vbCrLf
    s = s & "    If mode >= 4 Then" & vbCrLf
    s = s & "        txtP8.Text = IIf(mode = 4 Or mode = 6, ""3"", ""2"")" & vbCrLf
    s = s & "        txtP8.Visible = False: lblP8.Visible = False" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    chkVisible.Value = (GetSetting(APP_ID, section, ""visible"", ""1"") = ""1"")" & vbCrLf
    s = s & "End Sub" & vbCrLf
    Source_frmZekon_2 = s
End Function

Private Function Source_frmZekon_3() As String
    Dim s As String
    s = s & "" & vbCrLf
    s = s & "Private Sub cmdLoad_Click()" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    SelectMode mode" & vbCrLf
    s = s & "    lblStatus.Caption = ""Wczytano ustawienia: "" & txtProfile.Text" & vbCrLf
    s = s & "    Exit Sub" & vbCrLf
    s = s & "Bad:" & vbCrLf
    s = s & "    MsgBox Err.Description, vbExclamation, ""ZEKON""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub cmdSave_Click()" & vbCrLf
    s = s & "    Dim section As String, i As Long" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    section = SectionName()" & vbCrLf
    s = s & "    For i = 1 To 10" & vbCrLf
    s = s & "        SaveSetting APP_ID, section, ""p"" & i, Me.Controls(""txtP"" & i).Text" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    SaveSetting APP_ID, section, ""first_auto"", txtFirst.Text" & vbCrLf
    s = s & "    If mode = 2 Then SaveSetting APP_ID, section, ""target_first_auto"", txtP4.Text" & vbCrLf
    s = s & "    SaveSetting APP_ID, section, ""visible"", IIf(chkVisible.Value, ""1"", ""0"")" & vbCrLf
    s = s & "    lblStatus.Caption = ""Zapisano profil dla tej funkcji: "" & txtProfile.Text" & vbCrLf
    s = s & "    Exit Sub" & vbCrLf
    s = s & "Bad:" & vbCrLf
    s = s & "    MsgBox Err.Description, vbExclamation, ""ZEKON""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub cmdRun_Click()" & vbCrLf
    s = s & "    Dim wb As Workbook, ws As Worksheet, working As Workbook, sheetName As String" & vbCrLf
    s = s & "    Dim first As Long, i As Long, n As Long, p(1 To 10) As Variant, dummy As Long" & vbCrLf
    s = s & "    Dim oldEvents As Boolean, oldScreen As Boolean, altered As Boolean, mutating As Boolean" & vbCrLf
    s = s & "    Dim errorText As String, painting As Boolean, resultText As String" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    If busy Then Exit Sub" & vbCrLf
    s = s & "    LastCopyPath = """"" & vbCrLf
    s = s & "    Set wb = Application.Workbooks(CStr(cboBook.Value))" & vbCrLf
    s = s & "    sheetName = CStr(cboSheet.Value): Set ws = wb.Worksheets(sheetName)" & vbCrLf
    s = s & "    For i = 1 To 10" & vbCrLf
    s = s & "        p(i) = Trim$(Me.Controls(""txtP"" & i).Text)" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    busy = True" & vbCrLf
    Source_frmZekon_3 = s
End Function

Private Function Source_frmZekon_4() As String
    Dim s As String
    s = s & "    SetWorkingControls True" & vbCrLf
    s = s & "    oldEvents = Application.EnableEvents: oldScreen = Application.ScreenUpdating" & vbCrLf
    s = s & "    altered = True" & vbCrLf
    s = s & "    Application.EnableEvents = False: Application.ScreenUpdating = False" & vbCrLf
    s = s & "    BeginWork Me" & vbCrLf
    s = s & "    Select Case mode" & vbCrLf
    s = s & "        Case 1, 3: first = ResolveFirstRow(ws, CStr(p(1)), txtFirst.Text, True)" & vbCrLf
    s = s & "        Case 2: first = ResolveFirstRow(ws, CStr(p(1)), txtFirst.Text, False)" & vbCrLf
    s = s & "        Case Else: first = ResolveFirstRow(ws, CStr(p(3)), txtFirst.Text, False)" & vbCrLf
    s = s & "    End Select" & vbCrLf
    s = s & "    If mode >= 4 Then" & vbCrLf
    s = s & "        p(8) = IIf(mode = 4 Or mode = 6, ""3"", ""2"")" & vbCrLf
    s = s & "        For i = 2 To 7" & vbCrLf
    s = s & "            dummy = ColumnNumber(ws, CStr(p(i)))" & vbCrLf
    s = s & "        Next i" & vbCrLf
    s = s & "        If ColumnNumber(ws, CStr(p(5))) = ColumnNumber(ws, CStr(p(7))) Then Fail ""Dlugosc i numer sztuki wskazuja te sama kolumne.""" & vbCrLf
    s = s & "        dummy = WholeNumber(CStr(p(8)), ""Pierwszy wiersz eksportu"", ws.Rows.Count)" & vbCrLf
    s = s & "        If dummy < 2 Then Fail ""Pierwszy wiersz eksportu musi byc co najmniej 2.""" & vbCrLf
    s = s & "        If mode >= 6 Then" & vbCrLf
    s = s & "            dummy = ColumnNumber(ws, CStr(p(9)))" & vbCrLf
    s = s & "            If dummy = ColumnNumber(ws, CStr(p(7))) Then Fail ""Ilosc i numer sztuki musza byc w roznych kolumnach.""" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    If mode = 2 Then ValidateSearch ws, first, p, chkVisible.Value" & vbCrLf
    s = s & "    mutating = (mode <= 3 Or mode >= 6)" & vbCrLf
    s = s & "    If mutating And Not chkCopy.Value Then" & vbCrLf
    s = s & "        If MsgBox(""Zmienisz dane w oryginale: "" & wb.Name & "" / "" & ws.Name & vbCrLf & ""Operacji VBA nie mozna cofnac przez Ctrl+Z. Kontynuowac?"", vbYesNo + vbExclamation, ""ZEKON"") <> vbYes Then" & vbCrLf
    s = s & "            EndWork" & vbCrLf
    s = s & "            Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen" & vbCrLf
    s = s & "            altered = False: busy = False: SetWorkingControls False" & vbCrLf
    s = s & "            Exit Sub" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    If mutating And chkCopy.Value Then" & vbCrLf
    s = s & "        Set working = CopyWorkbook(wb)" & vbCrLf
    s = s & "        Set ws = working.Worksheets(sheetName)" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    Select Case mode" & vbCrLf
    s = s & "        Case 1: n = RoundColumn(ws, first, CStr(p(1)), chkVisible.Value, chkFormulas.Value)" & vbCrLf
    s = s & "        Case 2: n = SearchPositions(ws, first, p, chkVisible.Value)" & vbCrLf
    Source_frmZekon_4 = s
End Function

Private Function Source_frmZekon_5() As String
    Dim s As String
    s = s & "        Case 3: n = SplitRows(ws, first, CStr(p(1)), CStr(p(2)), chkVisible.Value)" & vbCrLf
    s = s & "        Case 4, 5: n = ExportRows(ws, first, p, chkVisible.Value, mode = 4)" & vbCrLf
    s = s & "        Case 6, 7" & vbCrLf
    s = s & "            n = SplitRows(ws, first, CStr(p(9)), CStr(p(7)), chkVisible.Value)" & vbCrLf
    s = s & "            ProgressTick ""Przeliczanie danych do eksportu"", 0, 0, True" & vbCrLf
    s = s & "            ws.Calculate" & vbCrLf
    s = s & "            n = ExportRows(ws, first, p, chkVisible.Value, mode = 6)" & vbCrLf
    s = s & "    End Select" & vbCrLf
    s = s & "    If mode = 1 Or mode = 3 Then" & vbCrLf
    s = s & "        ws.Parent.Activate" & vbCrLf
    s = s & "        ws.Activate" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    EndWork" & vbCrLf
    s = s & "    Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen" & vbCrLf
    s = s & "    altered = False: busy = False: SetWorkingControls False" & vbCrLf
    s = s & "    resultText = ""Gotowe. Poczatek danych zrodlowych: wiersz "" & first & "". """ & vbCrLf
    s = s & "    If mode = 2 Then resultText = resultText & ""Brakujacych wystapien: "" & n Else resultText = resultText & ""Przetworzonych wierszy/komorek: "" & n" & vbCrLf
    s = s & "    resultText = resultText & vbCrLf & ""Sprawdz wynik i zapisz go w wybranym miejscu.""" & vbCrLf
    s = s & "    If Len(LastCopyPath) > 0 Then resultText = resultText & vbCrLf & ""Kopia robocza: "" & LastCopyPath" & vbCrLf
    s = s & "    lblStatus.Caption = ""Gotowe. Wynik jest otwarty w Excelu.""" & vbCrLf
    s = s & "    MsgBox resultText, vbInformation, ""ZEKON""" & vbCrLf
    s = s & "    Unload Me" & vbCrLf
    s = s & "    Exit Sub" & vbCrLf
    s = s & "Bad:" & vbCrLf
    s = s & "    errorText = Err.Description" & vbCrLf
    s = s & "    If altered Then" & vbCrLf
    s = s & "        EndWork" & vbCrLf
    s = s & "        Application.EnableEvents = oldEvents: Application.ScreenUpdating = oldScreen" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    busy = False: SetWorkingControls False" & vbCrLf
    s = s & "    lblStatus.Caption = ""Operacja zatrzymana.""" & vbCrLf
    s = s & "    If Len(LastCopyPath) > 0 Then errorText = errorText & vbCrLf & ""Kopia robocza: "" & LastCopyPath" & vbCrLf
    s = s & "    MsgBox errorText & vbCrLf & ""W razie bledu w trakcie operacji sprawdz otwarty wynik; zmiany nie sa automatycznie wycofywane."", vbExclamation, ""ZEKON""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub cmdClose_Click()" & vbCrLf
    s = s & "    If busy Then" & vbCrLf
    s = s & "        RequestWorkCancel" & vbCrLf
    s = s & "        cmdClose.Enabled = False" & vbCrLf
    s = s & "        lblStatus.Caption = ""Przerywanie po zakonczeniu biezacej czynnosci...""" & vbCrLf
    Source_frmZekon_5 = s
End Function

Private Function Source_frmZekon_6() As String
    Dim s As String
    s = s & "    Else" & vbCrLf
    s = s & "        Unload Me" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub nav1_Click()" & vbCrLf
    s = s & "    SelectMode 1" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub nav2_Click()" & vbCrLf
    s = s & "    SelectMode 2" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub nav3_Click()" & vbCrLf
    s = s & "    SelectMode 3" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub nav4_Click()" & vbCrLf
    s = s & "    SelectMode 4" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub nav5_Click()" & vbCrLf
    s = s & "    SelectMode 5" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub nav6_Click()" & vbCrLf
    s = s & "    SelectMode 6" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "Private Sub nav7_Click()" & vbCrLf
    s = s & "    SelectMode 7" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub SetWorkingControls(ByVal working As Boolean)" & vbCrLf
    s = s & "    Dim ctl As Object" & vbCrLf
    s = s & "    For Each ctl In Me.Controls" & vbCrLf
    s = s & "        Select Case TypeName(ctl)" & vbCrLf
    s = s & "            Case ""CommandButton"", ""TextBox"", ""ComboBox"", ""CheckBox""" & vbCrLf
    s = s & "                ctl.Enabled = Not working" & vbCrLf
    s = s & "        End Select" & vbCrLf
    s = s & "    Next ctl" & vbCrLf
    s = s & "    cmdClose.Enabled = True" & vbCrLf
    s = s & "    cmdClose.Caption = IIf(working, ""Przerwij"", ""Zamknij"")" & vbCrLf
    s = s & "    If Not working Then chkCopy.Enabled = (mode <> 4 And mode <> 5)" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    Source_frmZekon_6 = s
End Function

Private Function Source_frmZekon_7() As String
    Dim s As String
    s = s & "Private Sub UserForm_QueryClose(Cancel As Integer, CloseMode As Integer)" & vbCrLf
    s = s & "    If busy Then" & vbCrLf
    s = s & "        Cancel = True" & vbCrLf
    s = s & "        RequestWorkCancel" & vbCrLf
    s = s & "        lblStatus.Caption = ""Przerywanie po zakonczeniu biezacej czynnosci...""" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "End Sub" & vbCrLf
    Source_frmZekon_7 = s
End Function

Private Function Source_modCore_0() As String
    Dim s As String
    s = s & "Option Explicit" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Const APP_ID As String = ""ZekonTools""" & vbCrLf
    s = s & "Public Const APP_VERSION As String = ""1.0.0-rc2c""" & vbCrLf
    s = s & "Public LastCopyPath As String" & vbCrLf
    s = s & "Private progressForm As Object" & vbCrLf
    s = s & "Private progressActive As Boolean, cancelRequested As Boolean" & vbCrLf
    s = s & "Private previousCalculation As XlCalculation" & vbCrLf
    s = s & "Private previousStatus As Variant, previousStatusVisible As Boolean" & vbCrLf
    s = s & "Private lastTick As Single, workStarted As Single" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub ZekonPanel()" & vbCrLf
    s = s & "    frmZekon.Show" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub Auto_Open()" & vbCrLf
    s = s & "    InstallMenu" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub Auto_Close()" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    Application.CommandBars(""Worksheet Menu Bar"").Controls(""ZEKON"").Delete" & vbCrLf
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub InstallMenu()" & vbCrLf
    s = s & "    Dim p As Object, b As Object" & vbCrLf
    s = s & "    Auto_Close" & vbCrLf
    s = s & "    Set p = Application.CommandBars(""Worksheet Menu Bar"").Controls.Add(Type:=10, Temporary:=True)" & vbCrLf
    s = s & "    p.Caption = ""ZEKON""" & vbCrLf
    s = s & "    Set b = p.Controls.Add(Type:=1, Temporary:=True)" & vbCrLf
    s = s & "    b.Caption = ""Otworz Narzedzia ZEKON""" & vbCrLf
    s = s & "    b.OnAction = ""'"" & Replace(ThisWorkbook.FullName, ""'"", ""''"") & ""'!modCore.ZekonPanel""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub Fail(ByVal message As String)" & vbCrLf
    s = s & "    Err.Raise vbObjectError + 701, ""Narzedzia ZEKON"", message" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function WholeNumber(ByVal value As String, ByVal title As String, ByVal maxValue As Long) As Long" & vbCrLf
    Source_modCore_0 = s
End Function

Private Function Source_modCore_1() As String
    Dim s As String
    s = s & "    Dim n As Double" & vbCrLf
    s = s & "    If Not IsNumeric(value) Then Fail title & "": wpisz liczbe calkowita.""" & vbCrLf
    s = s & "    n = CDbl(value)" & vbCrLf
    s = s & "    If n < 1 Or n > maxValue Or n <> Fix(n) Then Fail title & "": niepoprawna wartosc.""" & vbCrLf
    s = s & "    WholeNumber = CLng(n)" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function ColumnNumber(ByVal ws As Worksheet, ByVal value As String) As Long" & vbCrLf
    s = s & "    Dim i As Long, s As String, n As Long" & vbCrLf
    s = s & "    s = UCase$(Trim$(value))" & vbCrLf
    s = s & "    If Len(s) = 0 Or Len(s) > 3 Then Fail ""Niepoprawna kolumna: "" & value" & vbCrLf
    s = s & "    For i = 1 To Len(s)" & vbCrLf
    s = s & "        If Mid$(s, i, 1) < ""A"" Or Mid$(s, i, 1) > ""Z"" Then Fail ""Podaj litere kolumny: "" & value" & vbCrLf
    s = s & "        n = n * 26 + Asc(Mid$(s, i, 1)) - 64" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    If n > ws.Columns.Count Then Fail ""Kolumna poza arkuszem: "" & value" & vbCrLf
    s = s & "    ColumnNumber = n" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function LastRow(ByVal ws As Worksheet, ByVal col As Long) As Long" & vbCrLf
    s = s & "    LastRow = ws.Cells(ws.Rows.Count, col).End(xlUp).Row" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function Included(ByVal ws As Worksheet, ByVal row As Long, ByVal visibleOnly As Boolean) As Boolean" & vbCrLf
    s = s & "    Included = True" & vbCrLf
    s = s & "    If visibleOnly Then Included = Not ws.Rows(row).Hidden" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function PositionKey(ByVal value As Variant) As String" & vbCrLf
    s = s & "    If IsError(value) Then Fail ""Blad Excela w kolumnie pozycji. Popraw dane zrodlowe.""" & vbCrLf
    s = s & "    PositionKey = Trim$(Replace(CStr(value), ChrW(160), "" ""))" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function CopyWorkbook(ByVal source As Workbook) As Workbook" & vbCrLf
    s = s & "    Dim folder As String, path As String, ext As String, security As Long, i As Long" & vbCrLf
    s = s & "    Dim e As Long, message As String" & vbCrLf
    s = s & "    Select Case source.FileFormat" & vbCrLf
    s = s & "        Case 51: ext = "".xlsx""" & vbCrLf
    s = s & "        Case 52: ext = "".xlsm""" & vbCrLf
    s = s & "        Case 50: ext = "".xlsb""" & vbCrLf
    Source_modCore_1 = s
End Function

Private Function Source_modCore_2() As String
    Dim s As String
    s = s & "        Case 56, -4143: ext = "".xls""" & vbCrLf
    s = s & "        Case Else: Fail ""Kopia tego formatu nie jest obslugiwana. Zapisz dane jako XLSX/XLSM/XLSB/XLS.""" & vbCrLf
    s = s & "    End Select" & vbCrLf
    s = s & "    folder = Environ$(""LOCALAPPDATA"") & ""\ZekonTools""" & vbCrLf
    s = s & "    If Dir$(folder, vbDirectory) = """" Then MkDir folder" & vbCrLf
    s = s & "    folder = folder & ""\Kopie""" & vbCrLf
    s = s & "    If Dir$(folder, vbDirectory) = """" Then MkDir folder" & vbCrLf
    s = s & "    Do" & vbCrLf
    s = s & "        i = i + 1" & vbCrLf
    s = s & "        path = folder & ""\ZEKON_"" & Format$(Now, ""yyyymmdd_hhnnss"") & ""_"" & i & ext" & vbCrLf
    s = s & "    Loop While Len(Dir$(path)) > 0" & vbCrLf
    s = s & "    ProgressTick ""Zapisywanie kopii skoroszytu"", 0, 0, True" & vbCrLf
    s = s & "    source.SaveCopyAs path" & vbCrLf
    s = s & "    LastCopyPath = path" & vbCrLf
    s = s & "    security = Application.AutomationSecurity" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    Application.AutomationSecurity = 3" & vbCrLf
    s = s & "    ProgressTick ""Otwieranie kopii skoroszytu"", 0, 0, True" & vbCrLf
    s = s & "    Set CopyWorkbook = Application.Workbooks.Open(Filename:=path, UpdateLinks:=0, ReadOnly:=False)" & vbCrLf
    s = s & "    Application.AutomationSecurity = security" & vbCrLf
    s = s & "    Exit Function" & vbCrLf
    s = s & "Bad:" & vbCrLf
    s = s & "    e = Err.Number: message = Err.Description" & vbCrLf
    s = s & "    Application.AutomationSecurity = security" & vbCrLf
    s = s & "    Err.Raise e, ""CopyWorkbook"", message" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub EnsureWritable(ByVal ws As Worksheet)" & vbCrLf
    s = s & "    If ws.ProtectContents Then Fail ""Arkusz jest chroniony.""" & vbCrLf
    s = s & "    If ws.Parent.ReadOnly Then Fail ""Skoroszyt jest tylko do odczytu. Wybierz prace na kopii.""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function OwnMissingName(ByVal ws As Worksheet, ByVal col As Long) As String" & vbCrLf
    s = s & "    OwnMissingName = ""_ZEKON_missing_"" & ws.CodeName & ""_"" & CStr(col)" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "' AUTO is evaluated afresh for the selected worksheet and column on every run." & vbCrLf
    s = s & "Public Function ResolveFirstRow(ByVal ws As Worksheet, ByVal column As String, ByVal setting As String, Optional ByVal numericData As Boolean = False) As Long" & vbCrLf
    s = s & "    Dim col As Long, lo As ListObject, rg As Range, hit As Range, firstCell As Range" & vbCrLf
    s = s & "    Dim n As Long, firstAddress As String, headerRow As Long, candidate As Long" & vbCrLf
    Source_modCore_2 = s
End Function

Private Function Source_modCore_3() As String
    Dim s As String
    s = s & "    col = ColumnNumber(ws, column)" & vbCrLf
    s = s & "    If Len(Trim$(setting)) > 0 And UCase$(Trim$(setting)) <> ""AUTO"" Then" & vbCrLf
    s = s & "        ResolveFirstRow = WholeNumber(setting, ""Pierwszy wiersz danych"", ws.Rows.Count)" & vbCrLf
    s = s & "        Exit Function" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    ' More than one table in the column is ambiguous: never silently choose one." & vbCrLf
    s = s & "    For Each lo In ws.ListObjects" & vbCrLf
    s = s & "        If col >= lo.Range.Column And col < lo.Range.Column + lo.Range.Columns.Count Then" & vbCrLf
    s = s & "            If candidate <> 0 Then Fail ""Kilka tabel w kolumnie "" & column & "". Wskaz pierwszy wiersz zamiast AUTO.""" & vbCrLf
    s = s & "            If lo.DataBodyRange Is Nothing Then Fail ""Tabela w kolumnie "" & column & "" jest pusta.""" & vbCrLf
    s = s & "            candidate = lo.DataBodyRange.Row" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next lo" & vbCrLf
    s = s & "    If candidate > 0 Then ResolveFirstRow = candidate: Exit Function" & vbCrLf
    s = s & "    If ws.AutoFilterMode Then" & vbCrLf
    s = s & "        Set rg = ws.AutoFilter.Range" & vbCrLf
    s = s & "        If col >= rg.Column And col < rg.Column + rg.Columns.Count Then" & vbCrLf
    s = s & "            ResolveFirstRow = rg.Row + 1" & vbCrLf
    s = s & "            Exit Function" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    Set rg = ws.Columns(col)" & vbCrLf
    s = s & "    Set hit = rg.Find(What:=""*"", After:=ws.Cells(ws.Rows.Count, col), LookIn:=xlValues, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=False, SearchFormat:=False)" & vbCrLf
    s = s & "    If hit Is Nothing Then Fail ""Kolumna "" & column & "" w arkuszu "" & ws.Name & "" jest pusta.""" & vbCrLf
    s = s & "    Set firstCell = hit" & vbCrLf
    s = s & "    firstAddress = hit.Address" & vbCrLf
    s = s & "    ' Inspect up to 50 nonempty cells, including headers after blank title rows." & vbCrLf
    s = s & "    For n = 1 To 50" & vbCrLf
    s = s & "        If IsDataHeader(hit.Value2, numericData) Then" & vbCrLf
    s = s & "            headerRow = hit.Row" & vbCrLf
    s = s & "            Exit For" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "        Set hit = rg.Find(What:=""*"", After:=hit, LookIn:=xlValues, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=False, SearchFormat:=False)" & vbCrLf
    s = s & "        If hit Is Nothing Then Exit For" & vbCrLf
    s = s & "        If hit.Address = firstAddress Then Exit For" & vbCrLf
    s = s & "    Next n" & vbCrLf
    s = s & "    If headerRow > 0 Then" & vbCrLf
    s = s & "        Set hit = rg.Find(What:=""*"", After:=ws.Cells(headerRow, col), LookIn:=xlValues, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=False, SearchFormat:=False)" & vbCrLf
    s = s & "        If Not hit Is Nothing Then" & vbCrLf
    s = s & "            If hit.Row > headerRow Then" & vbCrLf
    Source_modCore_3 = s
End Function

Private Function Source_modCore_4() As String
    Dim s As String
    s = s & "                If IsDataValue(hit, numericData) Then ResolveFirstRow = hit.Row: Exit Function" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Else" & vbCrLf
    s = s & "        If IsDataValue(firstCell, numericData) Then ResolveFirstRow = firstCell.Row: Exit Function" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    Fail ""Nie mozna jednoznacznie rozpoznac poczatku danych: "" & ws.Name & "" / "" & column & "". Wpisz numer wiersza zamiast AUTO lub dodaj naglowek/filtr.""" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Function IsDataValue(ByVal cell As Range, ByVal numericData As Boolean) As Boolean" & vbCrLf
    s = s & "    Dim v As Variant, t As String" & vbCrLf
    s = s & "    v = cell.Value2" & vbCrLf
    s = s & "    If IsError(v) Or IsEmpty(v) Then Exit Function" & vbCrLf
    s = s & "    If cell.MergeCells Or VarType(v) = vbBoolean Then Exit Function" & vbCrLf
    s = s & "    t = Trim$(CStr(v))" & vbCrLf
    s = s & "    If Len(t) = 0 Then Exit Function" & vbCrLf
    s = s & "    If cell.HasFormula Then" & vbCrLf
    s = s & "        If InStr(1, cell.Formula, ""SUBTOTAL("", vbTextCompare) > 0 Then Exit Function" & vbCrLf
    s = s & "        If InStr(1, cell.Formula, ""SUM("", vbTextCompare) > 0 Then Exit Function" & vbCrLf
    s = s & "        If InStr(1, cell.Formula, ""AGGREGATE("", vbTextCompare) > 0 Then Exit Function" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    If numericData Then" & vbCrLf
    s = s & "        IsDataValue = IsNumeric(v)" & vbCrLf
    s = s & "    Else" & vbCrLf
    s = s & "        ' Headerless position lists: numeric IDs or codes containing digits." & vbCrLf
    s = s & "        IsDataValue = (t Like ""*[0-9]*"")" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Function IsDataHeader(ByVal v As Variant, ByVal numericData As Boolean) As Boolean" & vbCrLf
    s = s & "    Dim t As String" & vbCrLf
    s = s & "    If IsError(v) Or IsEmpty(v) Then Exit Function" & vbCrLf
    s = s & "    t = UCase$(Trim$(Replace(Replace(CStr(v), ChrW(160), "" ""), vbLf, "" "")))" & vbCrLf
    s = s & "    t = Replace(t, ChrW(211), ""O""): t = Replace(t, ChrW(321), ""L"")" & vbCrLf
    s = s & "    t = Replace(t, ChrW(346), ""S""): t = Replace(t, ChrW(262), ""C"")" & vbCrLf
    s = s & "    t = Replace(t, ChrW(280), ""E""): t = Replace(t, ChrW(260), ""A"")" & vbCrLf
    s = s & "    If numericData Then" & vbCrLf
    s = s & "        Select Case t" & vbCrLf
    s = s & "            Case ""PCS."", ""PCS"", ""QTY"", ""QUANTITY"", ""ILOSC"", ""SZT"", ""SZT."", ""ILOSC SZTUK"", ""WEIGHT/PCS"", ""WEIGHT TOT."", ""WEIGHT"", ""WAGA"", ""MASA"", ""MASA [KG]"", ""WAGA [KG]"", ""LENGTH"", ""LENGHT"", ""DLUGOSC"", ""WIDTH"", ""HEIGHT"", ""SURFACE/PCS"", ""SURFACE TOT."", ""WARTOSC"", ""VALUE""" & vbCrLf
    s = s & "                IsDataHeader = True" & vbCrLf
    Source_modCore_4 = s
End Function

Private Function Source_modCore_5() As String
    Dim s As String
    s = s & "        End Select" & vbCrLf
    s = s & "    Else" & vbCrLf
    s = s & "        Select Case t" & vbCrLf
    s = s & "            Case ""ASSEMBLY PART"", ""LEADING PART"", ""POZYCJA"", ""POZYCJE"", ""NR POZYCJI"", ""NUMER POZYCJI"", ""NUMERY POZYCJI"", ""POSITION"", ""POSITIONS"", ""POS"", ""POS."", ""PART NUMBER"", ""MARK"", ""ELEMENT"", ""NR ELEMENTU""" & vbCrLf
    s = s & "                IsDataHeader = True" & vbCrLf
    s = s & "        End Select" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub BeginWork(ByVal panel As Object)" & vbCrLf
    s = s & "    Set progressForm = panel" & vbCrLf
    s = s & "    previousCalculation = Application.Calculation" & vbCrLf
    s = s & "    previousStatus = Application.StatusBar" & vbCrLf
    s = s & "    previousStatusVisible = Application.DisplayStatusBar" & vbCrLf
    s = s & "    progressActive = True: cancelRequested = False" & vbCrLf
    s = s & "    workStarted = Timer: lastTick = -1" & vbCrLf
    s = s & "    Application.DisplayStatusBar = True" & vbCrLf
    s = s & "    Application.Calculation = xlCalculationManual" & vbCrLf
    s = s & "    ProgressTick ""Sprawdzanie ustawien"", 0, 0, True" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub EndWork()" & vbCrLf
    s = s & "    If Not progressActive Then Exit Sub" & vbCrLf
    s = s & "    ' Restore even when calculation or UI cleanup raises an error." & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    cancelRequested = False" & vbCrLf
    s = s & "    If Not progressForm Is Nothing Then" & vbCrLf
    s = s & "        progressForm.lblStatus.Caption = ""Konczenie pracy / przeliczanie...""" & vbCrLf
    s = s & "        progressForm.Repaint" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    Application.Calculation = previousCalculation" & vbCrLf
    s = s & "    Application.StatusBar = previousStatus" & vbCrLf
    s = s & "    Application.DisplayStatusBar = previousStatusVisible" & vbCrLf
    s = s & "    Set progressForm = Nothing" & vbCrLf
    s = s & "    progressActive = False" & vbCrLf
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub RequestWorkCancel()" & vbCrLf
    s = s & "    cancelRequested = True" & vbCrLf
    Source_modCore_5 = s
End Function

Private Function Source_modCore_6() As String
    Dim s As String
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Sub ProgressTick(ByVal phase As String, ByVal done As Long, ByVal total As Long, Optional ByVal force As Boolean = False)" & vbCrLf
    s = s & "    Dim nowTime As Single, elapsed As Long, ratio As Double, message As String" & vbCrLf
    s = s & "    If Not progressActive Then Exit Sub" & vbCrLf
    s = s & "    If cancelRequested Then Fail ""Przerwano na zyczenie uzytkownika. Wynik moze byc czesciowy.""" & vbCrLf
    s = s & "    If Not force Then" & vbCrLf
    s = s & "        If done Mod 64 <> 0 And done <> total Then Exit Sub" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    nowTime = Timer" & vbCrLf
    s = s & "    If Not force And lastTick >= 0 And nowTime >= lastTick Then" & vbCrLf
    s = s & "        If nowTime - lastTick < 0.2 Then Exit Sub" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    lastTick = nowTime" & vbCrLf
    s = s & "    elapsed = CLng(nowTime - workStarted)" & vbCrLf
    s = s & "    If elapsed < 0 Then elapsed = elapsed + 86400" & vbCrLf
    s = s & "    message = phase" & vbCrLf
    s = s & "    If total > 0 Then" & vbCrLf
    s = s & "        ratio = done / CDbl(total)" & vbCrLf
    s = s & "        If ratio > 1 Then ratio = 1" & vbCrLf
    s = s & "        message = message & "" "" & Format$(ratio, ""0%"") & "" ("" & done & ""/"" & total & "")""" & vbCrLf
    s = s & "    Else" & vbCrLf
    s = s & "        message = message & "" - prosze czekac""" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    message = message & "" | "" & elapsed & "" s""" & vbCrLf
    s = s & "    Application.StatusBar = ""ZEKON: "" & message" & vbCrLf
    s = s & "    If Not progressForm Is Nothing Then" & vbCrLf
    s = s & "        progressForm.lblStatus.Caption = message" & vbCrLf
    s = s & "        progressForm.progressFill.Width = 568 * ratio" & vbCrLf
    s = s & "        progressForm.Repaint" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    DoEvents" & vbCrLf
    s = s & "    If cancelRequested Then Fail ""Przerwano na zyczenie uzytkownika. Wynik moze byc czesciowy.""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function ReadColumnValues(ByVal ws As Worksheet, ByVal first As Long, ByVal finish As Long, ByVal col As Long) As Variant" & vbCrLf
    s = s & "    Dim singleValue(1 To 1, 1 To 1) As Variant" & vbCrLf
    s = s & "    If finish = first Then" & vbCrLf
    s = s & "        singleValue(1, 1) = ws.Cells(first, col).Value2" & vbCrLf
    s = s & "        ReadColumnValues = singleValue" & vbCrLf
    Source_modCore_6 = s
End Function

Private Function Source_modCore_7() As String
    Dim s As String
    s = s & "    Else" & vbCrLf
    s = s & "        ReadColumnValues = ws.Range(ws.Cells(first, col), ws.Cells(finish, col)).Value2" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "End Function" & vbCrLf
    Source_modCore_7 = s
End Function

Private Function Source_modExport_0() As String
    Dim s As String
    s = s & "Option Explicit" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function ExportRows(ByVal ws As Worksheet, ByVal first As Long, ByVal p As Variant, ByVal visibleOnly As Boolean, ByVal painting As Boolean) As Long" & vbCrLf
    s = s & "    Dim cols(1 To 6) As Long, i As Long, r As Long, finish As Long, n As Long, outRow As Long" & vbCrLf
    s = s & "    Dim data() As Variant, v As Variant, result As Workbook, dest As Worksheet, headings As Variant, sourceData As Variant, leftCol As Long, rightCol As Long" & vbCrLf
    s = s & "    For i = 1 To 6" & vbCrLf
    s = s & "        cols(i) = ColumnNumber(ws, CStr(p(i + 1)))" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    outRow = WholeNumber(CStr(p(8)), ""Pierwszy wiersz eksportu"", ws.Rows.Count)" & vbCrLf
    s = s & "    If outRow < 2 Then Fail ""Eksport musi zaczynac sie od wiersza 2 lub dalszego.""" & vbCrLf
    s = s & "    If cols(4) = cols(6) Then Fail ""Dlugosc i numer sztuki wskazuja te sama kolumne. Wybierz poprawne kolumny.""" & vbCrLf
    s = s & "    finish = LastRow(ws, cols(2))" & vbCrLf
    s = s & "    If finish < first Then Fail ""Brak pozycji do eksportu.""" & vbCrLf
    s = s & "    leftCol = cols(1): rightCol = cols(1)" & vbCrLf
    s = s & "    For i = 2 To 6" & vbCrLf
    s = s & "        If cols(i) < leftCol Then leftCol = cols(i)" & vbCrLf
    s = s & "        If cols(i) > rightCol Then rightCol = cols(i)" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    sourceData = ws.Range(ws.Cells(first, leftCol), ws.Cells(finish, rightCol)).Value2" & vbCrLf
    s = s & "    ProgressTick ""Eksport"", 0, finish - first + 1, True" & vbCrLf
    s = s & "    For r = first To finish" & vbCrLf
    s = s & "        ProgressTick ""Eksport"", r - first + 1, finish - first + 1" & vbCrLf
    s = s & "        If Included(ws, r, visibleOnly) Then" & vbCrLf
    s = s & "            If Len(PositionKey(sourceData(r - first + 1, cols(2) - leftCol + 1))) > 0 Then" & vbCrLf
    s = s & "                For i = 1 To 6" & vbCrLf
    s = s & "                    If IsError(sourceData(r - first + 1, cols(i) - leftCol + 1)) Then Fail ""Blad Excela w wierszu "" & r" & vbCrLf
    s = s & "                Next i" & vbCrLf
    s = s & "                v = sourceData(r - first + 1, cols(5) - leftCol + 1)" & vbCrLf
    s = s & "                If Len(CStr(v)) > 0 Then" & vbCrLf
    s = s & "                    If Not IsNumeric(v) Then Fail ""Waga nie jest liczba, wiersz "" & r" & vbCrLf
    s = s & "                End If" & vbCrLf
    s = s & "                n = n + 1" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    If n = 0 Then Fail ""Brak pozycji do eksportu.""" & vbCrLf
    s = s & "    If n + outRow - 1 > ws.Rows.Count Then Fail ""Za duzo wierszy eksportu.""" & vbCrLf
    s = s & "    ReDim data(1 To n, 1 To 7): n = 0" & vbCrLf
    s = s & "    ProgressTick ""Eksport"", 0, finish - first + 1, True" & vbCrLf
    s = s & "    For r = first To finish" & vbCrLf
    Source_modExport_0 = s
End Function

Private Function Source_modExport_1() As String
    Dim s As String
    s = s & "        ProgressTick ""Eksport"", r - first + 1, finish - first + 1" & vbCrLf
    s = s & "        If Included(ws, r, visibleOnly) Then" & vbCrLf
    s = s & "            If Len(PositionKey(sourceData(r - first + 1, cols(2) - leftCol + 1))) > 0 Then" & vbCrLf
    s = s & "                n = n + 1: data(n, 1) = CStr(p(1))" & vbCrLf
    s = s & "                For i = 1 To 6" & vbCrLf
    s = s & "                    data(n, i + 1) = sourceData(r - first + 1, cols(i) - leftCol + 1)" & vbCrLf
    s = s & "                Next i" & vbCrLf
    s = s & "                data(n, 2) = CStr(sourceData(r - first + 1, cols(1) - leftCol + 1))" & vbCrLf
    s = s & "                data(n, 3) = CStr(sourceData(r - first + 1, cols(2) - leftCol + 1))" & vbCrLf
    s = s & "                v = sourceData(r - first + 1, cols(5) - leftCol + 1)" & vbCrLf
    s = s & "                If Len(CStr(v)) > 0 Then" & vbCrLf
    s = s & "                    data(n, 6) = Application.WorksheetFunction.Round(CDbl(v), 0)" & vbCrLf
    s = s & "                Else" & vbCrLf
    s = s & "                    data(n, 6) = Empty" & vbCrLf
    s = s & "                End If" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    Set result = Application.Workbooks.Add(xlWBATWorksheet)" & vbCrLf
    s = s & "    Set dest = result.Worksheets(1)" & vbCrLf
    s = s & "    If painting Then" & vbCrLf
    s = s & "        dest.Name = ""Malowanie""" & vbCrLf
    s = s & "        headings = Array(""Auf.Name"", ""Auftr."", ""Pos."", ""Profil"", ""Lange"", ""Gewicht"", ""Lfn nr"")" & vbCrLf
    s = s & "    Else" & vbCrLf
    s = s & "        dest.Name = ""Ocynk""" & vbCrLf
    s = s & "        headings = Array(""Auf. Name"", ""Auftr."", ""Pos."", ""Profil"", ""Lange"", ""Gewicht"", ""Lfn nr"")" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    For i = 0 To 6" & vbCrLf
    s = s & "        dest.Cells(1, i + 1).Value2 = headings(i)" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    dest.Columns(""A:C"").NumberFormat = ""@""" & vbCrLf
    s = s & "    dest.Cells(outRow, 1).Resize(n, 7).Value2 = data" & vbCrLf
    s = s & "    dest.Rows(1).Font.Bold = True" & vbCrLf
    s = s & "    dest.Columns(""A:G"").AutoFit" & vbCrLf
    s = s & "    ExportRows = n" & vbCrLf
    s = s & "End Function" & vbCrLf
    Source_modExport_1 = s
End Function

Private Function Source_modRound_0() As String
    Dim s As String
    s = s & "Option Explicit" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function RoundColumn(ByVal ws As Worksheet, ByVal first As Long, ByVal column As String, ByVal visibleOnly As Boolean, ByVal overwriteFormulas As Boolean) As Long" & vbCrLf
    s = s & "    Dim c As Long, r As Long, finish As Long, cell As Range, v As Variant" & vbCrLf
    s = s & "    Dim block(1 To 2048, 1 To 1) As Variant, count As Long, start As Long, eligible As Boolean" & vbCrLf
    s = s & "    EnsureWritable ws" & vbCrLf
    s = s & "    c = ColumnNumber(ws, column): finish = LastRow(ws, c)" & vbCrLf
    s = s & "    ProgressTick ""Zaokraglanie"", 0, finish - first + 1, True" & vbCrLf
    s = s & "    For r = first To finish" & vbCrLf
    s = s & "        ProgressTick ""Zaokraglanie"", r - first + 1, finish - first + 1" & vbCrLf
    s = s & "        If Included(ws, r, visibleOnly) Then" & vbCrLf
    s = s & "            Set cell = ws.Cells(r, c)" & vbCrLf
    s = s & "            If cell.MergeCells Then Fail ""Scalona komorka w wierszu "" & r & "".""" & vbCrLf
    s = s & "            If cell.HasArray Then Fail ""Formula tablicowa w wierszu "" & r & "".""" & vbCrLf
    s = s & "            If IsError(cell.Value2) Then Fail ""Blad w wierszu "" & r & "".""" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    ProgressTick ""Zaokraglanie: zapis"", 0, finish - first + 1, True" & vbCrLf
    s = s & "    For r = first To finish" & vbCrLf
    s = s & "        eligible = False" & vbCrLf
    s = s & "        If Included(ws, r, visibleOnly) Then" & vbCrLf
    s = s & "            Set cell = ws.Cells(r, c): v = cell.Value2" & vbCrLf
    s = s & "            If Not cell.HasFormula Or overwriteFormulas Then" & vbCrLf
    s = s & "                If Not IsEmpty(v) And VarType(v) <> vbBoolean Then" & vbCrLf
    s = s & "                    If IsNumeric(v) And Len(CStr(v)) > 0 Then eligible = True" & vbCrLf
    s = s & "                End If" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "        If eligible Then" & vbCrLf
    s = s & "            If count = 0 Then start = r" & vbCrLf
    s = s & "            count = count + 1" & vbCrLf
    s = s & "            block(count, 1) = Application.WorksheetFunction.Round(CDbl(v), 0)" & vbCrLf
    s = s & "            RoundColumn = RoundColumn + 1" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "        If (Not eligible Or count = 2048 Or r = finish) And count > 0 Then" & vbCrLf
    s = s & "            WriteRoundedBlock ws, c, start, count, block" & vbCrLf
    s = s & "            count = 0" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "        ProgressTick ""Zaokraglanie: zapis"", r - first + 1, finish - first + 1" & vbCrLf
    s = s & "    Next r" & vbCrLf
    Source_modRound_0 = s
End Function

Private Function Source_modRound_1() As String
    Dim s As String
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub WriteRoundedBlock(ByVal ws As Worksheet, ByVal col As Long, ByVal first As Long, ByVal count As Long, ByRef block() As Variant)" & vbCrLf
    s = s & "    Dim values() As Variant, i As Long" & vbCrLf
    s = s & "    ReDim values(1 To count, 1 To 1)" & vbCrLf
    s = s & "    For i = 1 To count" & vbCrLf
    s = s & "        values(i, 1) = block(i, 1)" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    ws.Cells(first, col).Resize(count, 1).Value2 = values" & vbCrLf
    s = s & "End Sub" & vbCrLf
    Source_modRound_1 = s
End Function

Private Function Source_modSearch_0() As String
    Dim s As String
    s = s & "Option Explicit" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function SearchPositions(ByVal ws As Worksheet, ByVal first As Long, ByVal p As Variant, ByVal visibleOnly As Boolean) As Long" & vbCrLf
    s = s & "    Dim bt As Worksheet, sc As Long, bc As Long, br As Long, sr As Long, tr As Long" & vbCrLf
    s = s & "    Dim source As Object, target As Object, raw As Object, missing As Object" & vbCrLf
    s = s & "    Dim sourceValues As Variant, targetValues As Variant" & vbCrLf
    s = s & "    Dim r As Long, k As String, lastCol As Long, criteria As Variant, rg As Range, c As Range" & vbCrLf
    s = s & "    Dim report As Worksheet, row As Long, nm As String, formula As String, idx As Long, marker As Range" & vbCrLf
    s = s & "    Dim headerCell As Range, firstCol As Long, filterField As Long, key As Variant" & vbCrLf
    s = s & "    Dim filterValues() As String, filterIndex As Long, blockStart As Long" & vbCrLf
    s = s & "    EnsureWritable ws" & vbCrLf
    s = s & "    sc = ColumnNumber(ws, CStr(p(1)))" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    Set bt = ws.Parent.Worksheets(CStr(p(2)))" & vbCrLf
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "    If bt Is Nothing Then Fail ""Nie znaleziono arkusza: "" & CStr(p(2))" & vbCrLf
    s = s & "    If bt Is ws Then Fail ""Wybierz rozne arkusze: lista pozycji i zestawienie.""" & vbCrLf
    s = s & "    EnsureWritable bt" & vbCrLf
    s = s & "    If ws.Parent.ProtectStructure Then Fail ""Struktura skoroszytu jest chroniona.""" & vbCrLf
    s = s & "    If bt.ListObjects.Count > 0 Then Fail ""Wyszukiwanie wymaga zwyklego zakresu w arkuszu docelowym, nie tabeli Excela.""" & vbCrLf
    s = s & "    bc = ColumnNumber(bt, CStr(p(3)))" & vbCrLf
    s = s & "    br = ResolveFirstRow(bt, CStr(p(3)), CStr(p(4)), False)" & vbCrLf
    s = s & "    Set rg = SearchFilterRange(bt, br, bc)" & vbCrLf
    s = s & "    sr = LastRow(ws, sc): tr = LastRow(bt, bc)" & vbCrLf
    s = s & "    If sr < first Or tr < br Then Fail ""Brak danych w jednym z arkuszy.""" & vbCrLf
    s = s & "    sourceValues = ReadColumnValues(ws, first, sr, sc)" & vbCrLf
    s = s & "    targetValues = ReadColumnValues(bt, br, tr, bc)" & vbCrLf
    s = s & "    Set source = CreateObject(""Scripting.Dictionary""): source.CompareMode = vbTextCompare" & vbCrLf
    s = s & "    Set target = CreateObject(""Scripting.Dictionary""): target.CompareMode = vbTextCompare" & vbCrLf
    s = s & "    Set raw = CreateObject(""Scripting.Dictionary""): raw.CompareMode = vbTextCompare" & vbCrLf
    s = s & "    Set missing = CreateObject(""Scripting.Dictionary""): missing.CompareMode = vbTextCompare" & vbCrLf
    s = s & "    ProgressTick ""Wyszukiwanie: lista"", 0, sr - first + 1, True" & vbCrLf
    s = s & "    For r = first To sr" & vbCrLf
    s = s & "        ProgressTick ""Wyszukiwanie: lista"", r - first + 1, sr - first + 1" & vbCrLf
    s = s & "        If Included(ws, r, visibleOnly) Then" & vbCrLf
    s = s & "            k = PositionKey(sourceValues(r - first + 1, 1))" & vbCrLf
    s = s & "            If Len(k) > 0 Then source(k) = True" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    If source.Count = 0 Then Fail ""Lista pozycji jest pusta.""" & vbCrLf
    Source_modSearch_0 = s
End Function

Private Function Source_modSearch_1() As String
    Dim s As String
    s = s & "    ProgressTick ""Wyszukiwanie: zestawienie"", 0, tr - br + 1, True" & vbCrLf
    s = s & "    For r = br To tr" & vbCrLf
    s = s & "        ProgressTick ""Wyszukiwanie: zestawienie"", r - br + 1, tr - br + 1" & vbCrLf
    s = s & "        k = PositionKey(targetValues(r - br + 1, 1))" & vbCrLf
    s = s & "        If Len(k) > 0 Then" & vbCrLf
    s = s & "            target(k) = True" & vbCrLf
    s = s & "            If source.Exists(k) Then raw(CStr(targetValues(r - br + 1, 1))) = True" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    If raw.Count > 10000 Then Fail ""Za duzo kryteriow filtra (ponad 10 000). Podziel liste.""" & vbCrLf
    s = s & "    ProgressTick ""Wyszukiwanie: lista"", 0, sr - first + 1, True" & vbCrLf
    s = s & "    For r = first To sr" & vbCrLf
    s = s & "        ProgressTick ""Wyszukiwanie: lista"", r - first + 1, sr - first + 1" & vbCrLf
    s = s & "        If Included(ws, r, visibleOnly) Then" & vbCrLf
    s = s & "            k = PositionKey(sourceValues(r - first + 1, 1))" & vbCrLf
    s = s & "            If Len(k) > 0 Then" & vbCrLf
    s = s & "                If Not target.Exists(k) Then missing(CStr(r)) = k" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    Set rg = SearchFilterRange(bt, br, bc)" & vbCrLf
    s = s & "    filterField = bc - rg.Column + 1" & vbCrLf
    s = s & "    If bt.Visible <> xlSheetVisible Then Fail ""Arkusz zestawienia musi byc widoczny.""" & vbCrLf
    s = s & "    bt.Parent.Activate" & vbCrLf
    s = s & "    bt.Activate" & vbCrLf
    s = s & "    If bt.AutoFilterMode Then bt.AutoFilterMode = False" & vbCrLf
    s = s & "    If raw.Count = 1 Then" & vbCrLf
    s = s & "        For Each key In raw.Keys" & vbCrLf
    s = s & "            k = Replace(Replace(Replace(CStr(key), ""~"", ""~~""), ""*"", ""~*""), ""?"", ""~?"")" & vbCrLf
    s = s & "        Next key" & vbCrLf
    s = s & "        rg.AutoFilter Field:=filterField, Criteria1:=""="" & k" & vbCrLf
    s = s & "    ElseIf raw.Count > 1 Then" & vbCrLf
    s = s & "        ReDim filterValues(0 To raw.Count - 1)" & vbCrLf
    s = s & "        filterIndex = 0" & vbCrLf
    s = s & "        For Each key In raw.Keys" & vbCrLf
    s = s & "            filterValues(filterIndex) = CStr(key)" & vbCrLf
    s = s & "            filterIndex = filterIndex + 1" & vbCrLf
    s = s & "        Next key" & vbCrLf
    s = s & "        criteria = filterValues" & vbCrLf
    s = s & "        rg.AutoFilter Field:=filterField, Criteria1:=criteria, Operator:=xlFilterValues" & vbCrLf
    Source_modSearch_1 = s
End Function

Private Function Source_modSearch_2() As String
    Dim s As String
    s = s & "    Else" & vbCrLf
    s = s & "        k = ""__ZEKON_NO_MATCH__""" & vbCrLf
    s = s & "        Do While target.Exists(k)" & vbCrLf
    s = s & "            k = k & ""_""" & vbCrLf
    s = s & "        Loop" & vbCrLf
    s = s & "        rg.AutoFilter Field:=filterField, Criteria1:=""="" & k" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    ' Wlasne reguly CF oznaczaja stan z chwili wykonania i zachowuja wypelnienia." & vbCrLf
    s = s & "    Set report = ws.Parent.Worksheets.Add(After:=ws.Parent.Worksheets(ws.Parent.Worksheets.Count))" & vbCrLf
    s = s & "    report.Cells(1, 1).Value2 = ""Brakujaca pozycja""" & vbCrLf
    s = s & "    report.Cells(1, 2).Value2 = ""Wiersz zrodlowy""" & vbCrLf
    s = s & "    report.Cells(1, 4).Value2 = ws.Name" & vbCrLf
    s = s & "    report.Cells(2, 4).Value2 = ""Raport z "" & Format$(Now, ""yyyy-mm-dd hh:nn:ss"")" & vbCrLf
    s = s & "    report.Columns(1).NumberFormat = ""@"": row = 2" & vbCrLf
    s = s & "    ProgressTick ""Wyszukiwanie: lista"", 0, sr - first + 1, True" & vbCrLf
    s = s & "    For r = first To sr" & vbCrLf
    s = s & "        ProgressTick ""Wyszukiwanie: lista"", r - first + 1, sr - first + 1" & vbCrLf
    s = s & "        If missing.Exists(CStr(r)) Then" & vbCrLf
    s = s & "            report.Cells(row, 1).Value2 = missing(CStr(r))" & vbCrLf
    s = s & "            report.Cells(row, 2).Value2 = r: row = row + 1" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    If row = 2 Then report.Cells(2, 1).Value2 = ""Brak brakujacych pozycji""" & vbCrLf
    s = s & "    nm = OwnMissingName(ws, sc)" & vbCrLf
    s = s & "    Set marker = ws.Columns(sc)" & vbCrLf
    s = s & "    For idx = marker.FormatConditions.Count To 1 Step -1" & vbCrLf
    s = s & "        If marker.FormatConditions(idx).Type = xlExpression Then" & vbCrLf
    s = s & "            If InStr(1, marker.FormatConditions(idx).Formula1, nm, vbTextCompare) > 0 Then marker.FormatConditions(idx).Delete" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next idx" & vbCrLf
    s = s & "    ' Porownanie tekstow nie zalezy od jezyka funkcji ani separatora listy." & vbCrLf
    s = s & "    formula = ""="""""" & nm & """"""="""""" & nm & """"""""" & vbCrLf
    s = s & "    blockStart = 0" & vbCrLf
    s = s & "    ProgressTick ""Wyszukiwanie: lista"", 0, sr - first + 1, True" & vbCrLf
    s = s & "    For r = first To sr" & vbCrLf
    s = s & "        ProgressTick ""Wyszukiwanie: lista"", r - first + 1, sr - first + 1" & vbCrLf
    s = s & "        If missing.Exists(CStr(r)) Then" & vbCrLf
    s = s & "            If blockStart = 0 Then blockStart = r" & vbCrLf
    s = s & "        ElseIf blockStart > 0 Then" & vbCrLf
    s = s & "            MarkMissingBlock ws.Range(ws.Cells(blockStart, sc), ws.Cells(r - 1, sc)), formula" & vbCrLf
    Source_modSearch_2 = s
End Function

Private Function Source_modSearch_3() As String
    Dim s As String
    s = s & "            blockStart = 0" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    If blockStart > 0 Then MarkMissingBlock ws.Range(ws.Cells(blockStart, sc), ws.Cells(sr, sc)), formula" & vbCrLf
    s = s & "    report.Rows(1).Font.Bold = True: report.Columns(""A:D"").AutoFit" & vbCrLf
    s = s & "    bt.Activate" & vbCrLf
    s = s & "    SearchPositions = missing.Count" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub MarkMissingBlock(ByVal cells As Range, ByVal formula As String)" & vbCrLf
    s = s & "    With cells.FormatConditions.Add(Type:=xlExpression, Formula1:=formula)" & vbCrLf
    s = s & "        .Interior.Color = RGB(255, 199, 206)" & vbCrLf
    s = s & "        .SetFirstPriority" & vbCrLf
    s = s & "        .StopIfTrue = False" & vbCrLf
    s = s & "    End With" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "' Read-only validation: also called before creating a working copy." & vbCrLf
    s = s & "Public Sub ValidateSearch(ByVal ws As Worksheet, ByVal first As Long, ByVal p As Variant, ByVal visibleOnly As Boolean)" & vbCrLf
    s = s & "    Dim bt As Worksheet, rg As Range, sc As Long, bc As Long, br As Long, r As Long" & vbCrLf
    s = s & "    Dim found As Boolean" & vbCrLf
    s = s & "    EnsureWritable ws" & vbCrLf
    s = s & "    sc = ColumnNumber(ws, CStr(p(1)))" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    Set bt = ws.Parent.Worksheets(CStr(p(2)))" & vbCrLf
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "    If bt Is Nothing Then Fail ""Nie znaleziono arkusza: "" & CStr(p(2))" & vbCrLf
    s = s & "    If bt Is ws Then Fail ""Wybierz rozne arkusze: lista pozycji i zestawienie.""" & vbCrLf
    s = s & "    EnsureWritable bt" & vbCrLf
    s = s & "    If ws.Parent.ProtectStructure Then Fail ""Struktura skoroszytu jest chroniona.""" & vbCrLf
    s = s & "    If bt.ListObjects.Count > 0 Then Fail ""Wyszukiwanie wymaga zwyklego zakresu, nie tabeli Excela.""" & vbCrLf
    s = s & "    If bt.Visible <> xlSheetVisible Then Fail ""Arkusz zestawienia musi byc widoczny.""" & vbCrLf
    s = s & "    bc = ColumnNumber(bt, CStr(p(3)))" & vbCrLf
    s = s & "    br = ResolveFirstRow(bt, CStr(p(3)), CStr(p(4)), False)" & vbCrLf
    s = s & "    Set rg = SearchFilterRange(bt, br, bc)" & vbCrLf
    s = s & "    p(4) = CStr(br)" & vbCrLf
    s = s & "    For r = first To LastRow(ws, sc)" & vbCrLf
    s = s & "        ProgressTick ""Sprawdzanie listy"", r - first + 1, 0" & vbCrLf
    s = s & "        If Included(ws, r, visibleOnly) Then" & vbCrLf
    s = s & "            If Len(PositionKey(ws.Cells(r, sc).Value2)) > 0 Then found = True: Exit For" & vbCrLf
    Source_modSearch_3 = s
End Function

Private Function Source_modSearch_4() As String
    Dim s As String
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    If Not found Then Fail ""Lista pozycji jest pusta. Sprawdz arkusz listy, kolumne i opcje widocznych wierszy.""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Function SearchFilterRange(ByVal bt As Worksheet, ByVal firstData As Long, ByVal positionCol As Long) As Range" & vbCrLf
    s = s & "    Dim existing As Range, headerCell As Range, leftCol As Long, rightCol As Long, finish As Long, headerRow As Long" & vbCrLf
    s = s & "    If bt.AutoFilterMode Then Set existing = bt.AutoFilter.Range" & vbCrLf
    s = s & "    If firstData < 2 Then" & vbCrLf
    s = s & "        If Not existing Is Nothing Then" & vbCrLf
    s = s & "            Fail ""Pierwszy wiersz zestawienia oznacza pierwszy wiersz DANYCH. Dla istniejacego filtra w arkuszu "" & bt.Name & "" wpisz "" & (existing.Row + 1) & "".""" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "        Fail ""Pierwszy wiersz zestawienia oznacza pierwszy wiersz DANYCH i musi byc co najmniej 2.""" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    finish = LastRow(bt, positionCol)" & vbCrLf
    s = s & "    If finish < firstData Then Fail ""Brak danych w kolumnie pozycji zestawienia.""" & vbCrLf
    s = s & "    If Not existing Is Nothing Then" & vbCrLf
    s = s & "        If existing.Row = firstData - 1 Then" & vbCrLf
    s = s & "            leftCol = existing.Column" & vbCrLf
    s = s & "            rightCol = existing.Column + existing.Columns.Count - 1" & vbCrLf
    s = s & "            If positionCol < leftCol Then leftCol = positionCol" & vbCrLf
    s = s & "            If positionCol > rightCol Then rightCol = positionCol" & vbCrLf
    s = s & "            Set SearchFilterRange = bt.Range(bt.Cells(firstData - 1, leftCol), bt.Cells(finish, rightCol))" & vbCrLf
    s = s & "            Exit Function" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    headerRow = firstData - 1" & vbCrLf
    s = s & "    Do While headerRow > 1" & vbCrLf
    s = s & "        If Application.CountA(bt.Rows(headerRow)) > 0 Then Exit Do" & vbCrLf
    s = s & "        headerRow = headerRow - 1" & vbCrLf
    s = s & "    Loop" & vbCrLf
    s = s & "    Set headerCell = bt.Rows(headerRow).Find(What:=""*"", After:=bt.Cells(headerRow, 1), LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, LookAt:=xlPart, MatchCase:=False, SearchFormat:=False)" & vbCrLf
    s = s & "    If headerCell Is Nothing Then Fail ""Brak naglowkow bezposrednio nad danymi oraz zgodnego istniejacego filtra. Sprawdz pierwszy wiersz zestawienia.""" & vbCrLf
    s = s & "    rightCol = headerCell.Column" & vbCrLf
    s = s & "    Set headerCell = bt.Rows(headerRow).Find(What:=""*"", After:=bt.Cells(headerRow, bt.Columns.Count), LookIn:=xlFormulas, SearchOrder:=xlByColumns, SearchDirection:=xlNext, LookAt:=xlPart, MatchCase:=False, SearchFormat:=False)" & vbCrLf
    s = s & "    leftCol = headerCell.Column" & vbCrLf
    s = s & "    If positionCol < leftCol Then leftCol = positionCol" & vbCrLf
    s = s & "    If positionCol > rightCol Then rightCol = positionCol" & vbCrLf
    s = s & "    Set SearchFilterRange = bt.Range(bt.Cells(headerRow, leftCol), bt.Cells(finish, rightCol))" & vbCrLf
    s = s & "End Function" & vbCrLf
    Source_modSearch_4 = s
End Function

Private Function Source_modSelfTest_0() As String
    Dim s As String
    s = s & "Option Explicit" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub AssertTrue(ByVal condition As Boolean, ByVal message As String)" & vbCrLf
    s = s & "    If Not condition Then Fail ""TEST: "" & message" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function ZekonSelfTest() As String" & vbCrLf
    s = s & "    Dim wb As Workbook, ws As Worksheet, bt As Worksheet, result As Workbook" & vbCrLf
    s = s & "    Dim n As Long, p(1 To 10) As Variant, errCode As Long, oldAlerts As Boolean" & vbCrLf
    s = s & "    Dim e As Long, message As String, expectedFilter As String" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    oldAlerts = Application.DisplayAlerts" & vbCrLf
    s = s & "    Set wb = Workbooks.Add(xlWBATWorksheet): Set ws = wb.Worksheets(1)" & vbCrLf
    s = s & "    TestAutoStart wb" & vbCrLf
    s = s & "    TestSplitWithFilter wb" & vbCrLf
    s = s & "    TestWorkLifecycle" & vbCrLf
    s = s & "    ws.Name = ""Test""" & vbCrLf
    s = s & "    ws.Range(""F2"").Value2 = 2.5: ws.Range(""F3"").Formula = ""=2.5""" & vbCrLf
    s = s & "    ws.Range(""F4"").Value2 = -2.5: ws.Rows(4).Hidden = True" & vbCrLf
    s = s & "    n = RoundColumn(ws, 2, ""F"", True, False)" & vbCrLf
    s = s & "    AssertTrue n = 1, ""Zaokraglanie: liczba zmian""" & vbCrLf
    s = s & "    AssertTrue ws.Range(""F2"").Value2 = 3, ""Zaokraglanie polowek""" & vbCrLf
    s = s & "    AssertTrue ws.Range(""F3"").HasFormula, ""Ochrona formul""" & vbCrLf
    s = s & "    AssertTrue ws.Range(""F4"").Value2 = -2.5, ""Pominiecie ukrytych""" & vbCrLf
    s = s & "    ws.Rows(4).Hidden = False" & vbCrLf
    s = s & "    ws.Range(""A2"").Value2 = ""P1"": ws.Range(""E2"").Value2 = 3" & vbCrLf
    s = s & "    ws.Range(""H2"").Formula = ""=E2*10""" & vbCrLf
    s = s & "    ws.Rows(2).RowHeight = 27" & vbCrLf
    s = s & "    ws.Range(""A3"").Value2 = ""P2"": ws.Range(""E3"").Value2 = 2" & vbCrLf
    s = s & "    ws.Rows(3).Hidden = True" & vbCrLf
    s = s & "    n = SplitRows(ws, 2, ""E"", ""C"", True)" & vbCrLf
    s = s & "    AssertTrue n = 3, ""Rozbijanie: liczba sztuk""" & vbCrLf
    s = s & "    AssertTrue ws.Range(""C4"").Value2 = 3, ""Numer ostatniej sztuki""" & vbCrLf
    s = s & "    AssertTrue ws.Range(""H3"").Formula = ""=E3*10"" And ws.Range(""H4"").Formula = ""=E4*10"", ""Blokowe kopiowanie formul wzglednych""" & vbCrLf
    s = s & "    AssertTrue ws.Rows(3).RowHeight = 27 And ws.Rows(4).RowHeight = 27, ""Wysokosc kopiowanych wierszy""" & vbCrLf
    s = s & "    AssertTrue ws.Range(""E2"").Value2 = 1 And ws.Range(""E4"").Value2 = 1, ""Ilosc po rozbiciu""" & vbCrLf
    s = s & "    AssertTrue ws.Range(""E5"").Value2 = 2 And ws.Rows(5).Hidden, ""Ukryty wiersz bez rozbicia""" & vbCrLf
    s = s & "    ws.Range(""E2"").Value2 = 0" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    n = SplitRows(ws, 2, ""E"", ""C"", True)" & vbCrLf
    Source_modSelfTest_0 = s
End Function

Private Function Source_modSelfTest_1() As String
    Dim s As String
    s = s & "    errCode = Err.Number: Err.Clear" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    AssertTrue errCode <> 0, ""Odrzucenie zerowej ilosci""" & vbCrLf
    s = s & "    ws.Range(""E2"").Value2 = 1" & vbCrLf
    s = s & "    ws.Range(""D2:D4"").NumberFormat = ""@"": ws.Range(""D2:D4"").Value2 = ""001""" & vbCrLf
    s = s & "    ws.Range(""B2:B4"").Value2 = ""K1"": ws.Range(""M2:M4"").Value2 = ""HEA100""" & vbCrLf
    s = s & "    ws.Range(""H2:H4"").Value2 = 1000: ws.Range(""F2:F4"").Value2 = 2.5" & vbCrLf
    s = s & "    p(1) = ""Test"": p(2) = ""B"": p(3) = ""D"": p(4) = ""M""" & vbCrLf
    s = s & "    p(5) = ""H"": p(6) = ""F"": p(7) = ""C"": p(8) = ""3""" & vbCrLf
    s = s & "    n = ExportRows(ws, 2, p, True, True)" & vbCrLf
    s = s & "    Set result = ActiveWorkbook" & vbCrLf
    s = s & "    AssertTrue n = 3, ""Eksport widocznych""" & vbCrLf
    s = s & "    AssertTrue result.Worksheets(1).Range(""C3"").Value2 = ""001"", ""Zera wiodace""" & vbCrLf
    s = s & "    AssertTrue result.Worksheets(1).Range(""F3"").Value2 = 3, ""Waga eksportu""" & vbCrLf
    s = s & "    AssertTrue IsEmpty(result.Worksheets(1).Range(""A2"").Value2), ""Wiersz 2 malowania""" & vbCrLf
    s = s & "    result.Close SaveChanges:=False: Set result = Nothing" & vbCrLf
    s = s & "    Set bt = wb.Worksheets.Add: bt.Name = ""bt-list""" & vbCrLf
    s = s & "    bt.Range(""B7"").Value2 = ""Pozycja"": bt.Range(""B8"").Value2 = ""P1""" & vbCrLf
    s = s & "    bt.Range(""B9"").Value2 = ""P3"": ws.Rows(5).Hidden = False" & vbCrLf
    s = s & "    p(1) = ""A"": p(2) = ""bt-list"": p(3) = ""B"": p(4) = ""8""" & vbCrLf
    s = s & "    n = SearchPositions(ws, 2, p, True)" & vbCrLf
    s = s & "    AssertTrue n = 1, ""Wykrywanie brakow""" & vbCrLf
    s = s & "    AssertTrue Not bt.Rows(8).Hidden And bt.Rows(9).Hidden, ""Filtr pozycji""" & vbCrLf
    s = s & "    AssertTrue ws.Cells(5, 1).FormatConditions.Count > 0, ""Oznaczenie braku""" & vbCrLf
    s = s & "    bt.Range(""B10"").Value2 = ""P2""" & vbCrLf
    s = s & "    n = SearchPositions(ws, 2, p, True)" & vbCrLf
    s = s & "    AssertTrue n = 0, ""Kilka dopasowan bez brakow""" & vbCrLf
    s = s & "    AssertTrue Not bt.Rows(8).Hidden And bt.Rows(9).Hidden And Not bt.Rows(10).Hidden, ""Filtr wielu pozycji""" & vbCrLf
    s = s & "    AssertTrue ws.Cells(5, 1).FormatConditions.Count = 0, ""Usuniecie nieaktualnego oznaczenia""" & vbCrLf
    s = s & "    bt.Range(""B8"").Value2 = ""X1"": bt.Range(""B10"").Value2 = ""X2""" & vbCrLf
    s = s & "    n = SearchPositions(ws, 2, p, True)" & vbCrLf
    s = s & "    AssertTrue n = 4, ""Brak dopasowan""" & vbCrLf
    s = s & "    AssertTrue bt.Rows(8).Hidden And bt.Rows(9).Hidden And bt.Rows(10).Hidden, ""Pusty wynik filtra""" & vbCrLf
    s = s & "    ' Reproduce LieferlisteZMSCG: headers in 6, blank filter row 7, data from 8." & vbCrLf
    s = s & "    bt.AutoFilterMode = False" & vbCrLf
    s = s & "    bt.Range(""B7"").ClearContents" & vbCrLf
    s = s & "    bt.Range(""B6"").Value2 = ""ASSEMBLY PART""" & vbCrLf
    s = s & "    bt.Range(""B8"").Value2 = ""P1"": bt.Range(""B10"").Value2 = ""P2""" & vbCrLf
    s = s & "    bt.Range(""A7:BD10"").AutoFilter" & vbCrLf
    s = s & "    expectedFilter = bt.AutoFilter.Range.Address(True, True, xlA1)" & vbCrLf
    Source_modSelfTest_1 = s
End Function

Private Function Source_modSelfTest_2() As String
    Dim s As String
    s = s & "    AssertTrue bt.AutoFilter.Range.Row = 7 And bt.AutoFilter.Range.Rows.Count = 4, ""Wiersze filtra przed wyszukiwaniem""" & vbCrLf
    s = s & "    p(4) = ""1"": errCode = 0" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    ValidateSearch ws, 2, p, True" & vbCrLf
    s = s & "    errCode = Err.Number: Err.Clear" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    AssertTrue errCode <> 0, ""Preflight odrzuca pierwszy wiersz 1""" & vbCrLf
    s = s & "    p(4) = ""8""" & vbCrLf
    s = s & "    ValidateSearch ws, 2, p, True" & vbCrLf
    s = s & "    n = SearchPositions(ws, 2, p, True)" & vbCrLf
    s = s & "    AssertTrue n = 0, ""Pusty wiersz naglowka istniejacego filtra""" & vbCrLf
    s = s & "    AssertTrue bt.AutoFilter.Range.Address(True, True, xlA1) = expectedFilter, ""Zachowany zakres filtra: oczekiwany "" & expectedFilter & "", otrzymany "" & bt.AutoFilter.Range.Address(True, True, xlA1)" & vbCrLf
    s = s & "    AssertTrue Not bt.Rows(8).Hidden And bt.Rows(9).Hidden And Not bt.Rows(10).Hidden, ""Filtr ukladu Lieferliste""" & vbCrLf
    s = s & "    wb.Close SaveChanges:=False: Set wb = Nothing" & vbCrLf
    s = s & "    TestPanelVersion" & vbCrLf
    s = s & "    Application.DisplayAlerts = oldAlerts" & vbCrLf
    s = s & "    ZekonSelfTest = ""PASS: rounding, formulas, hidden rows, split, zero quantity, export, leading zeros, filter, missing report, blank filter header, preflight, automatic starts, block copy, batch rounding, cancellation, calculation restore, form initialization, filtered split, filtered split all rows, filtered last row, filter criteria restore, permanent version label.""" & vbCrLf
    s = s & "    Exit Function" & vbCrLf
    s = s & "Bad:" & vbCrLf
    s = s & "    e = Err.Number: message = Err.Description" & vbCrLf
    s = s & "    EndWork" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    If Not result Is Nothing Then result.Close SaveChanges:=False" & vbCrLf
    s = s & "    If Not wb Is Nothing Then wb.Close SaveChanges:=False" & vbCrLf
    s = s & "    Unload frmZekon" & vbCrLf
    s = s & "    Application.DisplayAlerts = oldAlerts" & vbCrLf
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "    Err.Raise e, ""ZekonSelfTest"", message" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub TestAutoStart(ByVal wb As Workbook)" & vbCrLf
    s = s & "    Dim ws As Worksheet, lo As ListObject, n As Long, e As Long" & vbCrLf
    s = s & "    Dim alerts As Boolean" & vbCrLf
    s = s & "    Set ws = wb.Worksheets.Add" & vbCrLf
    s = s & "    ws.Range(""F6"").Value2 = ""WEIGHT/PCS"": ws.Range(""F8"").Value2 = 2.5" & vbCrLf
    s = s & "    AssertTrue ResolveFirstRow(ws, ""F"", ""AUTO"", True) = 8, ""Auto: naglowek i pusty wiersz""" & vbCrLf
    s = s & "    n = RoundColumn(ws, ResolveFirstRow(ws, ""F"", ""AUTO"", True), ""F"", False, False)" & vbCrLf
    s = s & "    AssertTrue ws.Range(""F8"").Value2 = 3, ""Zaokraglanie od wykrytego poczatku""" & vbCrLf
    s = s & "    ws.Cells.Clear" & vbCrLf
    s = s & "    ws.Range(""A1"").Value2 = ""P001"": ws.Range(""A2"").Value2 = ""P002""" & vbCrLf
    Source_modSelfTest_2 = s
End Function

Private Function Source_modSelfTest_3() As String
    Dim s As String
    s = s & "    AssertTrue ResolveFirstRow(ws, ""A"", ""AUTO"") = 1, ""Auto: lista bez naglowka""" & vbCrLf
    s = s & "    ws.Cells.Clear" & vbCrLf
    s = s & "    ws.Range(""B4"").Value2 = ""Pozycja"": ws.Range(""B5"").Value2 = ""P1""" & vbCrLf
    s = s & "    AssertTrue ResolveFirstRow(ws, ""B"", ""AUTO"") = 5, ""Auto: naglowek w innym wierszu""" & vbCrLf
    s = s & "    ws.Cells.Clear" & vbCrLf
    s = s & "    ws.Range(""B12"").Value2 = ""P1"": ws.Range(""B13"").Value2 = ""P2""" & vbCrLf
    s = s & "    ws.Range(""A11:D13"").AutoFilter" & vbCrLf
    s = s & "    ws.Rows(12).Hidden = True" & vbCrLf
    s = s & "    AssertTrue ResolveFirstRow(ws, ""B"", ""AUTO"") = 12, ""Auto: filtr, pusty naglowek, ukryty pierwszy wiersz""" & vbCrLf
    s = s & "    ws.AutoFilterMode = False: ws.Rows(12).Hidden = False: ws.Cells.Clear" & vbCrLf
    s = s & "    ws.Range(""B3"").Value2 = ""Pozycja"": ws.Range(""B4"").Value2 = ""P1""" & vbCrLf
    s = s & "    Set lo = ws.ListObjects.Add(xlSrcRange, ws.Range(""B3:B4""), , xlYes)" & vbCrLf
    s = s & "    AssertTrue ResolveFirstRow(ws, ""B"", ""AUTO"") = 4, ""Auto: tabela Excela""" & vbCrLf
    s = s & "    lo.Unlist: ws.Cells.Clear" & vbCrLf
    s = s & "    ws.Range(""A1"").Value2 = ""Nieznany tytul"": ws.Range(""A2"").Value2 = 2.5" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    n = ResolveFirstRow(ws, ""A"", ""AUTO"", True)" & vbCrLf
    s = s & "    e = Err.Number: Err.Clear" & vbCrLf
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "    AssertTrue e <> 0, ""Auto: niejednoznaczny tytul wymaga wskazania""" & vbCrLf
    s = s & "    AssertTrue ResolveFirstRow(ws, ""A"", ""2"", True) = 2, ""Reczne nadpisanie AUTO""" & vbCrLf
    s = s & "    ws.Cells.Clear" & vbCrLf
    s = s & "    ws.Range(""F2:F2052"").Value2 = 2.5" & vbCrLf
    s = s & "    n = RoundColumn(ws, 2, ""F"", False, False)" & vbCrLf
    s = s & "    AssertTrue n = 2051 And ws.Range(""F2052"").Value2 = 3, ""Zapis zaokraglen ponad granica porcji 2048""" & vbCrLf
    s = s & "    alerts = Application.DisplayAlerts" & vbCrLf
    s = s & "    Application.DisplayAlerts = False" & vbCrLf
    s = s & "    ws.Delete" & vbCrLf
    s = s & "    Application.DisplayAlerts = alerts" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub TestWorkLifecycle()" & vbCrLf
    s = s & "    Dim previous As XlCalculation, e As Long, panel As Object" & vbCrLf
    s = s & "    previous = Application.Calculation" & vbCrLf
    s = s & "    BeginWork panel" & vbCrLf
    s = s & "    AssertTrue Application.Calculation = xlCalculationManual, ""Wstrzymanie przeliczania""" & vbCrLf
    s = s & "    RequestWorkCancel" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    ProgressTick ""Test przerwania"", 1, 1, True" & vbCrLf
    s = s & "    e = Err.Number: Err.Clear" & vbCrLf
    Source_modSelfTest_3 = s
End Function

Private Function Source_modSelfTest_4() As String
    Dim s As String
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "    EndWork" & vbCrLf
    s = s & "    AssertTrue e <> 0, ""Zadanie przerwania jest obslugiwane""" & vbCrLf
    s = s & "    AssertTrue Application.Calculation = previous, ""Przywrocenie przeliczania po przerwaniu""" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub TestSplitWithFilter(ByVal wb As Workbook)" & vbCrLf
    s = s & "    Dim ws As Worksheet, n As Long, scenario As Long, e As Long" & vbCrLf
    s = s & "    Set ws = wb.Worksheets.Add" & vbCrLf
    s = s & "    For scenario = 1 To 4" & vbCrLf
    s = s & "        ws.AutoFilterMode = False: ws.Cells.Clear: ws.Rows(""1:20"").Hidden = False" & vbCrLf
    s = s & "        ws.Range(""A1"").Value2 = ""Group"": ws.Range(""B1"").Value2 = ""Qty""" & vbCrLf
    s = s & "        ws.Range(""C1"").Value2 = ""Piece"": ws.Range(""D1"").Value2 = ""Formula""" & vbCrLf
    s = s & "        ws.Range(""A2"").Value2 = ""YES"": ws.Range(""B2"").Value2 = 2" & vbCrLf
    s = s & "        ws.Range(""A3"").Value2 = ""NO"": ws.Range(""B3"").Value2 = 4" & vbCrLf
    s = s & "        ws.Range(""A4"").Value2 = ""YES"": ws.Range(""B4"").Value2 = 3" & vbCrLf
    s = s & "        ws.Range(""D2:D4"").FormulaR1C1 = ""=RC[-2]*10""" & vbCrLf
    s = s & "        ws.Range(""A1:D4"").AutoFilter Field:=1, Criteria1:=Array(""YES""), Operator:=xlFilterValues" & vbCrLf
    s = s & "        If scenario <> 4 Then ws.Range(""A1:D4"").AutoFilter Field:=2, Criteria1:="">=2"", Operator:=xlAnd, Criteria2:=""<=4""" & vbCrLf
    s = s & "        If scenario = 3 Then" & vbCrLf
    s = s & "            ws.Range(""B2"").Value2 = 0" & vbCrLf
    s = s & "            On Error Resume Next" & vbCrLf
    s = s & "            n = SplitRows(ws, 2, ""B"", ""C"", True)" & vbCrLf
    s = s & "            e = Err.Number: Err.Clear" & vbCrLf
    s = s & "            On Error GoTo 0" & vbCrLf
    s = s & "            AssertTrue e <> 0, ""Filtrowane rozbijanie: walidacja przed zmianami""" & vbCrLf
    s = s & "            AssertTrue ws.AutoFilter.Range.Rows.Count = 4 And ws.Rows(3).Hidden, ""Filtr zachowany po bledzie walidacji""" & vbCrLf
    s = s & "        Else" & vbCrLf
    s = s & "            n = SplitRows(ws, 2, ""B"", ""C"", scenario <> 2)" & vbCrLf
    s = s & "            If scenario <> 2 Then" & vbCrLf
    s = s & "                AssertTrue n = 5, ""Rozbijanie tylko widocznych pod filtrem""" & vbCrLf
    s = s & "                AssertTrue ws.Range(""A4"").Value2 = ""NO"" And ws.Range(""B4"").Value2 = 4, ""Odfiltrowana pozycja bez zmian""" & vbCrLf
    s = s & "                AssertTrue ws.Range(""C7"").Value2 = 3 And ws.Range(""D7"").Formula = ""=B7*10"", ""Ostatni filtrowany wiersz i formula""" & vbCrLf
    s = s & "                AssertTrue ws.AutoFilter.Range.Address = ""$A$1:$D$7"", ""Powiekszony zakres filtra""" & vbCrLf
    s = s & "            Else" & vbCrLf
    s = s & "                AssertTrue n = 9 And ws.Range(""C7"").Value2 = 4, ""Rozbijanie wszystkich przy aktywnym filtrze""" & vbCrLf
    s = s & "                AssertTrue ws.AutoFilter.Range.Address = ""$A$1:$D$10"", ""Zakres filtra po rozbiciu wszystkich""" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "            If scenario = 4 Then" & vbCrLf
    s = s & "                AssertTrue Not ws.Rows(2).Hidden And ws.Rows(4).Hidden And Not ws.Rows(7).Hidden, ""Widocznosc po rozbiciu nieciaglych pozycji""" & vbCrLf
    Source_modSelfTest_4 = s
End Function

Private Function Source_modSelfTest_5() As String
    Dim s As String
    s = s & "                AssertTrue ws.AutoFilter.Filters(1).On, ""Przywrocony filtr pozycji""" & vbCrLf
    s = s & "            Else" & vbCrLf
    s = s & "                AssertTrue ws.AutoFilter.Filters(1).On And ws.AutoFilter.Filters(2).On, ""Przywrocone oba filtry""" & vbCrLf
    s = s & "                AssertTrue ws.AutoFilter.Filters(2).Criteria1 = "">=2"" And ws.AutoFilter.Filters(2).Criteria2 = ""<=4"", ""Przywrocone kryteria AND""" & vbCrLf
    s = s & "                AssertTrue ws.Rows(2).Hidden, ""Filtr ilosci ponownie oceniony po zmianie na 1""" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next scenario" & vbCrLf
    s = s & "End Sub" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub TestPanelVersion()" & vbCrLf
    s = s & "    Dim panel As frmZekon, actual As String, expected As String" & vbCrLf
    s = s & "    Dim e As Long, message As String" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    Set panel = New frmZekon" & vbCrLf
    s = s & "    Load panel" & vbCrLf
    s = s & "    expected = ""Wersja: "" & APP_VERSION" & vbCrLf
    s = s & "    actual = CStr(panel.Controls(""version"").Caption)" & vbCrLf
    s = s & "    AssertTrue StrComp(actual, expected, vbBinaryCompare) = 0, ""Wersja panelu: oczekiwano ["" & expected & ""]; odczytano ["" & Replace(Replace(actual, vbCr, ""<CR>""), vbLf, ""<LF>"") & ""]""" & vbCrLf
    s = s & "    AssertTrue panel.Caption = ""Narzedzia ZEKON | "" & APP_VERSION, ""Wersja paska tytulu""" & vbCrLf
    s = s & "    Unload panel" & vbCrLf
    s = s & "    Set panel = Nothing" & vbCrLf
    s = s & "    Exit Sub" & vbCrLf
    s = s & "Bad:" & vbCrLf
    s = s & "    e = Err.Number: message = Err.Description" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    If Not panel Is Nothing Then Unload panel" & vbCrLf
    s = s & "    Set panel = Nothing" & vbCrLf
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "    Err.Raise e, ""TestPanelVersion"", message" & vbCrLf
    s = s & "End Sub" & vbCrLf
    Source_modSelfTest_5 = s
End Function

Private Function Source_modSplit_0() As String
    Dim s As String
    s = s & "Option Explicit" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Public Function SplitRows(ByVal ws As Worksheet, ByVal first As Long, ByVal quantityColumn As String, ByVal sequenceColumn As String, ByVal visibleOnly As Boolean) As Long" & vbCrLf
    s = s & "    Dim qc As Long, sc As Long, finish As Long, r As Long, n As Long, j As Long" & vbCrLf
    s = s & "    Dim quantityValues As Variant" & vbCrLf
    s = s & "    Dim v As Variant, extra As Double, quantities() As Long, bottom As Range, sequence() As Variant, rowHeight As Double, rowHidden As Boolean" & vbCrLf
    s = s & "    Dim filterState As Variant, filterTop As Long, filterBottom As Long, filterLeft As Long, filterWidth As Long" & vbCrLf
    s = s & "    Dim restoreNeeded As Boolean, e As Long, message As String, restoreError As String" & vbCrLf
    s = s & "    On Error GoTo Bad" & vbCrLf
    s = s & "    EnsureWritable ws" & vbCrLf
    s = s & "    qc = ColumnNumber(ws, quantityColumn): sc = ColumnNumber(ws, sequenceColumn)" & vbCrLf
    s = s & "    If qc = sc Then Fail ""Ilosc i numer sztuki musza byc w roznych kolumnach.""" & vbCrLf
    s = s & "    If ws.ListObjects.Count > 0 Then Fail ""Rozbijanie: najpierw zamien tabele Excela na zwykly zakres (Projekt tabeli > Konwertuj na zakres).""" & vbCrLf
    s = s & "    finish = LastRow(ws, qc)" & vbCrLf
    s = s & "    If finish < first Then Fail ""Brak danych do rozbicia.""" & vbCrLf
    s = s & "    ReDim quantities(first To finish)" & vbCrLf
    s = s & "    quantityValues = ReadColumnValues(ws, first, finish, qc)" & vbCrLf
    s = s & "    ProgressTick ""Sprawdzanie ilosci"", 0, finish - first + 1, True" & vbCrLf
    s = s & "    For r = first To finish" & vbCrLf
    s = s & "        ProgressTick ""Sprawdzanie ilosci"", r - first + 1, finish - first + 1" & vbCrLf
    s = s & "        If Included(ws, r, visibleOnly) Then" & vbCrLf
    s = s & "            v = quantityValues(r - first + 1, 1)" & vbCrLf
    s = s & "            If IsError(v) Then Fail ""Blad ilosci w wierszu "" & r" & vbCrLf
    s = s & "            If Len(CStr(v)) > 0 Then" & vbCrLf
    s = s & "                quantities(r) = WholeNumber(CStr(v), ""Ilosc, wiersz "" & r, ws.Rows.Count)" & vbCrLf
    s = s & "                If IsNull(ws.Rows(r).MergeCells) Then Fail ""Scalone komorki w wierszu "" & r" & vbCrLf
    s = s & "                If ws.Rows(r).MergeCells Then Fail ""Scalone komorki w wierszu "" & r" & vbCrLf
    s = s & "                extra = extra + quantities(r) - 1" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    Set bottom = ws.Cells.Find(What:=""*"", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False, SearchFormat:=False)" & vbCrLf
    s = s & "    If Not bottom Is Nothing Then" & vbCrLf
    s = s & "        If bottom.Row + extra > ws.Rows.Count Then Fail ""Za malo wierszy w arkuszu.""" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    If extra > 100000 Then Fail ""Jedna operacja moze dodac najwyzej 100 000 wierszy. Podziel dane na mniejsze partie.""" & vbCrLf
    s = s & "    ' quantities is the immutable selection captured while the original filter is active." & vbCrLf
    s = s & "    If ws.AutoFilterMode Then" & vbCrLf
    s = s & "        filterState = CaptureSplitFilter(ws, filterTop, filterBottom, filterLeft, filterWidth)" & vbCrLf
    s = s & "        If first <= filterTop And finish >= filterTop Then Fail ""Poczatek danych obejmuje naglowek filtra.""" & vbCrLf
    Source_modSplit_0 = s
End Function

Private Function Source_modSplit_1() As String
    Dim s As String
    s = s & "        restoreNeeded = True" & vbCrLf
    s = s & "        If ws.FilterMode Then ws.ShowAllData" & vbCrLf
    s = s & "        ws.AutoFilterMode = False" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    ProgressTick ""Rozbijanie: wiersze zrodlowe"", 0, finish - first + 1, True" & vbCrLf
    s = s & "    For r = finish To first Step -1" & vbCrLf
    s = s & "        n = quantities(r)" & vbCrLf
    s = s & "        If n > 0 Then" & vbCrLf
    s = s & "            rowHeight = ws.Rows(r).RowHeight: rowHidden = ws.Rows(r).Hidden" & vbCrLf
    s = s & "            If n > 1 Then" & vbCrLf
    s = s & "                ws.Rows(r + 1).Resize(n - 1).Insert Shift:=xlDown" & vbCrLf
    s = s & "                ' Track successful inserts, including copies of the last filtered row." & vbCrLf
    s = s & "                If restoreNeeded Then" & vbCrLf
    s = s & "                    If r < filterTop Then" & vbCrLf
    s = s & "                        filterTop = filterTop + n - 1: filterBottom = filterBottom + n - 1" & vbCrLf
    s = s & "                    ElseIf r <= filterBottom Then" & vbCrLf
    s = s & "                        filterBottom = filterBottom + n - 1" & vbCrLf
    s = s & "                    End If" & vbCrLf
    s = s & "                End If" & vbCrLf
    s = s & "                ' Repeat the source row over one destination block. Excel adjusts formulas." & vbCrLf
    s = s & "                ws.Rows(r).Copy Destination:=ws.Rows(r + 1).Resize(n - 1)" & vbCrLf
    s = s & "                ws.Rows(r + 1).Resize(n - 1).Hidden = rowHidden" & vbCrLf
    s = s & "                ws.Rows(r + 1).Resize(n - 1).RowHeight = rowHeight" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "            ReDim sequence(1 To n, 1 To 1)" & vbCrLf
    s = s & "            For j = 1 To n" & vbCrLf
    s = s & "                sequence(j, 1) = j" & vbCrLf
    s = s & "            Next j" & vbCrLf
    s = s & "            ws.Cells(r, qc).Resize(n, 1).Value2 = 1" & vbCrLf
    s = s & "            ws.Cells(r, sc).Resize(n, 1).Value2 = sequence" & vbCrLf
    s = s & "            SplitRows = SplitRows + n" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "        ProgressTick ""Rozbijanie: wiersze zrodlowe"", finish - r + 1, finish - first + 1" & vbCrLf
    s = s & "    Next r" & vbCrLf
    s = s & "    Application.CutCopyMode = False" & vbCrLf
    s = s & "    If restoreNeeded Then" & vbCrLf
    s = s & "        RestoreSplitFilter ws, filterState, filterTop, filterBottom, filterLeft, filterWidth" & vbCrLf
    s = s & "        restoreNeeded = False" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    Exit Function" & vbCrLf
    Source_modSplit_1 = s
End Function

Private Function Source_modSplit_2() As String
    Dim s As String
    s = s & "Bad:" & vbCrLf
    s = s & "    e = Err.Number: message = Err.Description" & vbCrLf
    s = s & "    On Error Resume Next" & vbCrLf
    s = s & "    Application.CutCopyMode = False" & vbCrLf
    s = s & "    If restoreNeeded Then" & vbCrLf
    s = s & "        Err.Clear" & vbCrLf
    s = s & "        RestoreSplitFilter ws, filterState, filterTop, filterBottom, filterLeft, filterWidth" & vbCrLf
    s = s & "        If Err.Number <> 0 Then restoreError = Err.Description" & vbCrLf
    s = s & "    End If" & vbCrLf
    s = s & "    On Error GoTo 0" & vbCrLf
    s = s & "    If Len(restoreError) > 0 Then message = message & vbCrLf & ""Nie odtworzono filtra: "" & restoreError" & vbCrLf
    s = s & "    Err.Raise e, ""SplitRows"", message" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Function CaptureSplitFilter(ByVal ws As Worksheet, ByRef top As Long, ByRef bottom As Long, ByRef left As Long, ByRef width As Long) As Variant" & vbCrLf
    s = s & "    Dim rg As Range, item As Filter, state() As Variant, i As Long, op As Long" & vbCrLf
    s = s & "    Set rg = ws.AutoFilter.Range" & vbCrLf
    s = s & "    top = rg.Row: bottom = top + rg.Rows.Count - 1" & vbCrLf
    s = s & "    left = rg.Column: width = rg.Columns.Count" & vbCrLf
    s = s & "    ReDim state(1 To width, 1 To 6)" & vbCrLf
    s = s & "    For i = 1 To width" & vbCrLf
    s = s & "        Set item = ws.AutoFilter.Filters(i)" & vbCrLf
    s = s & "        state(i, 1) = item.On" & vbCrLf
    s = s & "        If item.On Then" & vbCrLf
    s = s & "            op = item.Operator: state(i, 2) = op" & vbCrLf
    s = s & "            If op = xlFilterIcon Then Fail ""Rozbijanie: filtr ikon wymaga wczesniejszej zamiany na filtr wartosci. Dane nie zostaly zmienione.""" & vbCrLf
    s = s & "            ' Criteria1 or Criteria2 can be absent, including grouped date filters." & vbCrLf
    s = s & "            On Error Resume Next" & vbCrLf
    s = s & "            Err.Clear: state(i, 3) = item.Criteria1: state(i, 5) = (Err.Number = 0)" & vbCrLf
    s = s & "            Err.Clear: state(i, 4) = item.Criteria2: state(i, 6) = (Err.Number = 0)" & vbCrLf
    s = s & "            Err.Clear" & vbCrLf
    s = s & "            On Error GoTo 0" & vbCrLf
    s = s & "            If Not state(i, 5) And Not state(i, 6) Then Fail ""Nie mozna odczytac kryteriow filtra. Dane nie zostaly zmienione.""" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "    CaptureSplitFilter = state" & vbCrLf
    s = s & "End Function" & vbCrLf
    s = s & "" & vbCrLf
    s = s & "Private Sub RestoreSplitFilter(ByVal ws As Worksheet, ByVal state As Variant, ByVal top As Long, ByVal bottom As Long, ByVal left As Long, ByVal width As Long)" & vbCrLf
    s = s & "    Dim rg As Range, i As Long" & vbCrLf
    Source_modSplit_2 = s
End Function

Private Function Source_modSplit_3() As String
    Dim s As String
    s = s & "    ws.AutoFilterMode = False" & vbCrLf
    s = s & "    Set rg = ws.Range(ws.Cells(top, left), ws.Cells(bottom, left + width - 1))" & vbCrLf
    s = s & "    rg.AutoFilter" & vbCrLf
    s = s & "    For i = 1 To width" & vbCrLf
    s = s & "        If state(i, 1) Then" & vbCrLf
    s = s & "            If state(i, 5) And state(i, 6) Then" & vbCrLf
    s = s & "                rg.AutoFilter Field:=i, Criteria1:=state(i, 3), Operator:=state(i, 2), Criteria2:=state(i, 4)" & vbCrLf
    s = s & "            ElseIf state(i, 5) Then" & vbCrLf
    s = s & "                If state(i, 2) = 0 Then" & vbCrLf
    s = s & "                    rg.AutoFilter Field:=i, Criteria1:=state(i, 3)" & vbCrLf
    s = s & "                Else" & vbCrLf
    s = s & "                    rg.AutoFilter Field:=i, Criteria1:=state(i, 3), Operator:=state(i, 2)" & vbCrLf
    s = s & "                End If" & vbCrLf
    s = s & "            Else" & vbCrLf
    s = s & "                rg.AutoFilter Field:=i, Operator:=state(i, 2), Criteria2:=state(i, 4)" & vbCrLf
    s = s & "            End If" & vbCrLf
    s = s & "        End If" & vbCrLf
    s = s & "    Next i" & vbCrLf
    s = s & "End Sub" & vbCrLf
    Source_modSplit_3 = s
End Function

Private Sub WriteEmbeddedLogo(ByVal path As String)
    Dim f As Integer, n As Long, msg As String
    On Error GoTo Failed
    f = FreeFile
    Open path For Binary Access Write As #f
    LogoPart0 f
    LogoPart1 f
    LogoPart2 f
    LogoPart3 f
    LogoPart4 f
    LogoPart5 f
    LogoPart6 f
    LogoPart7 f
    LogoPart8 f
    LogoPart9 f
    LogoPart10 f
    LogoPart11 f
    LogoPart12 f
    LogoPart13 f
    LogoPart14 f
    LogoPart15 f
    LogoPart16 f
    LogoPart17 f
    LogoPart18 f
    LogoPart19 f
    LogoPart20 f
    LogoPart21 f
    LogoPart22 f
    LogoPart23 f
    LogoPart24 f
    LogoPart25 f
    LogoPart26 f
    LogoPart27 f
    LogoPart28 f
    LogoPart29 f
    LogoPart30 f
    LogoPart31 f
    LogoPart32 f
    LogoPart33 f
    LogoPart34 f
    LogoPart35 f
    LogoPart36 f
    LogoPart37 f
    LogoPart38 f
    LogoPart39 f
    Close #f
    Exit Sub
Failed:
    n = Err.Number: msg = Err.Description
    On Error Resume Next
    Close #f
    On Error GoTo 0
    Err.Raise n, "WriteEmbeddedLogo", msg
End Sub
Private Sub WriteHex(ByVal f As Integer, ByVal value As String)
    Dim b() As Byte, i As Long
    ReDim b(0 To Len(value) \ 2 - 1)
    For i = 0 To UBound(b)
        b(i) = CByte("&H" & Mid$(value, i * 2 + 1, 2))
    Next i
    Put #f, , b
End Sub
Private Sub LogoPart0(ByVal f As Integer)
    WriteHex f, "424DDABF0500000000003600000028000000CB010000110100000100180000000000A4BF0500C40E0000C40E00000000000000000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E474706BCDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF9A979436302936302968635ECDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1423C363630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFF2F2F274706B3630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029423C36F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F8CAC8F0AFACE99591E28783DE5F59D35F59D35F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECC5F59D35F59D3"
    WriteHex f, "6D67D79591E2A29EE6CAC8F0D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F0A29EE67A75DB5F59D32B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECC6D67D79591E2BCBAEDF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E436302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED8783DE5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECC7A75DBAFACE9E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart1(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7C0BEBC9A9794B3B1AED9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2CDCBC9C0BEBC9A9794A7A4A1CDCBC9E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4B3B1AE9A9794C0BEBCD9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4B3B1AEB3B1AEF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2CDCBC99A9794A7A4A1"
    WriteHex f, "CDCBC9D9D8D7FFFFFFFFFFFFFFFFFFFFFFFF5B5650363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9B3B1AE9A9794B3B1AECDCBC9E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4CDCBC9B3B1AE"
    WriteHex f, "9A9794B3B1AECDCBC9F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7A7A4A19A9794CDCBC9E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2C0BEBCA7A4A1D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4C0BEBC9A9794B3B1AECDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9B3B1AE9A9794B3B1AECDCBC9E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F8A29EE66D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD09591E2D7D6F4FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000423C363630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029D9D8D7FFFFFFFFFFFFFFFFFFD9D8D768635E363029363029"
    WriteHex f, "3630293630293630294E4943B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029E6E5E4FFFFFFFFFFFFB3B1AE4E49433630293630293630293630293630293630293630295B5650CDCBC9FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFC0BEBC36302936302936302936302936302974706BFFFFFFD9D8D73630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A8636302936302936302936302974706BD9D8D7FFFFFF36302936302974706BFFFFFFFFFFFFFFFFFFCDCBC9363029"
    WriteHex f, "3630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1423C36363029363029363029363029363029363029B3B1AEFFFFFFFFFFFF8D8A86363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC4E4943363029363029363029"
    WriteHex f, "363029363029363029423C36817D79E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86423C3636302936302936302936302936302936302936302974706BD9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A863630293630293630293630293630299A9794FFFFFF"
    WriteHex f, "FFFFFFFFFFFFB3B1AE423C363630293630293630294E4943C0BEBCFFFFFFA7A4A1363029363029CDCBC9FFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D768635E3630293630293630293630293630294E4943A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF9A9794363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC4E4943363029363029363029363029363029363029423C36817D79E6E5E4FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFE4E3F8A29EE6524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECC8783DED7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000074706B363029"
    WriteHex f, "363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E43630293630294E4943FFFFFFFFFFFFFFFFFFE6E5E4423C36363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "A7A4A1363029363029B3B1AEFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B565036302936302936302936302936302968635EFFFFFFFFFFFF3630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029A7A4A15B5650363029423C36FFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029B3B1AEFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029"
    WriteHex f, "363029363029363029817D79FFFFFFFFFFFFB3B1AE363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFF2F2F23630293630293630293630293630293630299A9794FFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029817D79CDCBC9363029363029A7A4A1FFFFFFFFFFFFFFFFFF9A9794363029363029"
    WriteHex f, "CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFE6E5E4423C36363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A97943630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E3630293630293630293630299A9794FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE95F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C5453ECCA29EE6F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF0000009A9794363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A13630293630298D8A86FFFFFFFFFFFFFFFFFF817D793630293630295B5650D9D8D7"
    WriteHex f, "FFFFFFF2F2F2B3B1AE423C36363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D73630293630298D8A86FFFFFFFFFFFFF2F2F29A9794C0BEBCCDCBC9FFFFFFFFFFFFFFFFFFE6E5E49A9794423C36363029363029B3B1AEFFFFFF"
    WriteHex f, "FFFFFFFFFFFFD9D8D73630293630294E4943E6E5E4FFFFFFE6E5E4D9D8D7FFFFFFFFFFFF68635E363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D7936302936302968635EE6E5E4CDCBC9817D79363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFF68635E"
    WriteHex f, "363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C36363029423C36FFFFFFFFFFFFFFFFFFFFFFFF4E494336302936302974706BD9D8D7FFFFFFFFFFFFE6E5E4C0BEBCB3B1AEFFFFFFFFFFFFE6E5E4363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFF74706B3630293630294E4943A7A4A1E6E5E4"
    WriteHex f, "FFFFFFE6E5E4CDCBC9A7A4A1817D79D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D79A9794CDCBC9D9D8D7FFFFFFFFFFFFFFFFFFD9D8D7817D79363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFA7A4A136302936302974706BF2F2F2FFFFFFD9D8D7E6E5E4FFFFFF"
    WriteHex f, "FFFFFF9A97943630293630295B5650B3B1AED9D8D7817D7936302936302974706B3630293630299A9794FFFFFFFFFFFFFFFFFFC0BEBC3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFF817D793630293630295B5650D9D8D7FFFFFFF2F2F2B3B1AE423C36363029363029817D79FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF9A97943630293630298D8A86363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFF68635E3630295B56504E4943363029423C36F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B3630293630294E4943A7A4A1E6E5E4FFFFFFE6E5E4CDCBC9A7A4A1817D79D9D8D7FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F8"
    WriteHex f, "8783DE3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBCAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000CDCBC9363029"
    WriteHex f, "3630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029CDCBC9FFFFFFFFFFFFFFFFFF423C36363029423C36F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029C0BEBCFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF423C363630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D73630293630294E4943FFFFFFFFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF68635E363029363029E6E5E4FFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029B3B1AEFFFFFFFFFFFFFFFFFF8D8A86363029363029CDCBC9FFFFFFFFFFFFFFFFFFC0BEBC363029363029817D79FFFFFFFFFFFFFFFFFFE6E5E43630293630294E4943F2F2F2FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630294E4943FFFFFFFFFFFFFFFFFFFFFFFF363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029817D79FFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029CDCBC9FFFFFFFFFFFFFFFFFFD9D8D7423C3636302936302936302968635EFFFFFFFFFFFFFFFFFFF2F2F2363029363029"
    WriteHex f, "68635EFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029CDCBC95B56503630294E4943FFFFFFFFFFFFFFFFFFFFFFFF68635E36302968635EB3B1AE363029363029A7A4A1"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C36363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F47A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C55F59D3AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFF3630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630294E4943FFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029F2F2F2"
    WriteHex f, "FFFFFFFFFFFFE6E5E436302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029817D79FFFFFFFFFFFFFFFFFFC0BEBC"
    WriteHex f, "363029363029A7A4A1FFFFFFFFFFFFFFFFFF817D79363029363029C0BEBCFFFFFFFFFFFFFFFFFFCDCBC9363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029F2F2F2FFFFFFFFFFFFFFFFFF3630293630294E4943FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3630293630294E4943FFFFFFFFFFFFFFFFFFB3B1AE3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFF5B5650363029423C36FFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630294E4943FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFCDCBC9363029363029CDCBC9B3B1AE363029363029C0BEBCFFFFFFFFFFFFFFFFFF68635E36302968635EFFFFFF423C363630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F05F59D32B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCAFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFF68635E"
    WriteHex f, "363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029C0BEBCFFFFFFFFFFFFC0BEBC3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029CDCBC9FFFFFFFFFFFFFFFFFF423C363630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F236302936302968635EFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF74706B363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C363630295B5650FFFFFFFFFFFFFFFFFFF2F2F236302936302974706BFFFFFFFFFFFFF2F2F2363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029C0BEBCFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C36363029363029FFFFFFFFFFFFFFFFFFD9D8D7363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029D9D8D7FFFFFFFFFFFFFFFFFF817D79363029"
    WriteHex f, "363029D9D8D7FFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029B3B1AEFFFFFFFFFFFFFFFFFFCDCBC9363029363029CDCBC9FFFFFF4E494336302968635EFFFFFFFFFFFFFFFFFF68635E36302968635EFFFFFF9A9794363029363029"
    WriteHex f, "B3B1AEFFFFFFFFFFFFFFFFFFFFFFFF3630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F45F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart2(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCAFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFF8D8A86363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029817D79FFFFFFFFFFFFF2F2F236302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F29A9794363029363029363029E6E5E4"
    WriteHex f, "FFFFFFFFFFFFFFFFFF74706B363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029F2F2F2FFFFFFFFFFFFFFFFFF"
    WriteHex f, "4E4943363029423C36FFFFFFFFFFFFB3B1AE3630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630298D8A86FFFFFFFFFFFFFFFFFF363029363029363029FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4817D79363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFF423C363630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF68635E363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029A7A4A1FFFFFFFFFFFFFFFFFFB3B1AE363029363029A7A4A1FFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC936302936302974706BFFFFFF"
    WriteHex f, "FFFFFFFFFFFFCDCBC9363029363029CDCBC9FFFFFFB3B1AE363029363029CDCBC9FFFFFFFFFFFF423C3636302968635EFFFFFFF2F2F2423C363630295B5650FFFFFFFFFFFFFFFFFFFFFFFF363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F87A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFC0BEBC"
    WriteHex f, "3630293630299A9794FFFFFFFFFFFFFFFFFFF2F2F2363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630294E4943FFFFFFFFFFFFFFFFFF5B5650363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D78D8A865B56503630293630293630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029D9D8D7FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029C0BEBCFFFFFFFFFFFFFFFFFF817D79363029363029C0BEBCCDCBC968635E363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3630293630295B5650FFFFFFFFFFFFFFFFFF5B56503630293630299A97949A97949A97949A9794A7A4A1CDCBC9E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "C0BEBC817D794E49433630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029817D79FFFFFFFFFFFFFFFFFFE6E5E4363029"
    WriteHex f, "363029817D79FFFFFFFFFFFFFFFFFF4E4943363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C36363029423C36FFFFFFFFFFFFFFFFFFCDCBC9363029363029CDCBC9FFFFFFFFFFFF4E494336302968635EFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFF817D79363029"
    WriteHex f, "363029CDCBC9FFFFFFFFFFFFFFFFFF68635E3630293630299A97949A97949A97949A9794A7A4A1CDCBC9E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB9591E23730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFF2F2F236302936302968635EFFFFFFFFFFFFFFFFFFB3B1AE363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029F2F2F2FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029F2F2F2FFFFFFFFFFFF817D79363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFD9D8D768635E363029363029363029363029363029363029817D79F2F2F2FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFCDCBC93630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F236302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFF"
    WriteHex f, "B3B1AE3630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029"
    WriteHex f, "3630293630293630293630294E49439A9794F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC4E4943363029363029363029363029363029423C369A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFB3B1AE3630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630294E4943FFFFFFFFFFFFFFFFFFFFFFFF4E49433630294E4943FFFFFFFFFFFFFFFFFF68635E363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029E6E5E4"
    WriteHex f, "FFFFFFFFFFFFCDCBC9363029363029B3B1AEFFFFFFFFFFFFB3B1AE363029363029CDCBC9FFFFFF36302936302968635EFFFFFFFFFFFFE6E5E436302936302968635EFFFFFFFFFFFFFFFFFF74706B3630293630293630293630293630293630293630293630293630294E49439A9794F2F2F2FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F0453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C89591E2FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "4E4943363029363029FFFFFFFFFFFFFFFFFF74706B363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFB3B1AE363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF8D8A86363029363029CDCBC9FFFFFFFFFFFFFFFFFF4E4943363029363029363029423C3674706BB3B1AEF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E436302936302974706BFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFF5B5650363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029E6E5E4FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFA7A4A13630293630294E494368635E68635E68635E68635E3630293630293630293630295B5650F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029"
    WriteHex f, "3630293630294E4943817D79C0BEBCF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E43630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029E6E5E4FFFFFFFFFFFFFFFFFF74706B"
    WriteHex f, "363029363029E6E5E4FFFFFFFFFFFF9A9794363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFF4E494336302974706BFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFF74706B"
    WriteHex f, "363029363029E6E5E4FFFFFFFFFFFFA7A4A13630293630294E494368635E68635E68635E68635E3630293630293630293630295B5650F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D736302936302974706BFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFE6E5E4363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029B3B1AEFFFFFFFFFFFFE6E5E4363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF423C363630294E4943CDCBC9C0BEBC423C36363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFA7A4A13630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC3630293630299A9794FFFFFFFFFFFFE6E5E43630293630295B5650FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFCDCBC95B5650363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029423C36CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF5B5650363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029C0BEBCFFFFFFFFFFFFFFFFFFA7A4A1363029363029C0BEBCFFFFFFFFFFFFD9D8D736302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9"
    WriteHex f, "FFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFA7A4A1363029363029E6E5E436302936302968635EFFFFFFFFFFFFFFFFFFCDCBC9363029363029817D79FFFFFFFFFFFFE6E5E43630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC95B5650363029363029817D79FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "B3B1AE3630293630293630293630293630293630293630294E4943F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFF423C36363029363029D9D8D7FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFE6E5E43630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029E6E5E4FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029CDCBC9FFFFFFFFFFFFFFFFFF74706B363029363029F2F2F2FFFFFFCDCBC9363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFE6E5E4363029363029423C36F2F2F2FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F236302936302968635EFFFFFFFFFFFFFFFFFF68635E363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C36363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029"
    WriteHex f, "8D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE36302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D73630293630298D8A86FFFFFFFFFFFFFFFFFFD9D8D7"
    WriteHex f, "3630293630298D8A86FFFFFFFFFFFFFFFFFF68635E363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFF2F2F2423C36363029817D793630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "68635E363029363029E6E5E4FFFFFFFFFFFF74706B363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C36363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFD9D8D73630293630294E49439A97949A979468635E363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC36302936302968635E"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029CDCBC9FFFFFFFFFFFFFFFFFF74706B363029363029423C36CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFF363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFC0BEBC3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029423C369A9794F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029A7A4A1FFFFFFFFFFFF"
    WriteHex f, "FFFFFF9A9794363029363029C0BEBCFFFFFFFFFFFFB3B1AE363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFF817D79363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029423C36FFFFFFFFFFFFFFFFFFCDCBC93630293630295B5650FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF4E4943363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630295B5650FFFFFFFFFFFFFFFFFFFFFFFF3630293630295B5650FFFFFFFFFFFFFFFFFFCDCBC93630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029CDCBC9"
    WriteHex f, "FFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFF9A97943630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFB3B1AE3630293630299A9794FFFFFFFFFFFFCDCBC93630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart3(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C53730C8AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFF423C363630294E4943FFFFFFFFFFFFF2F2F24E4943363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029F2F2F2FFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029A7A4A1FFFFFF"
    WriteHex f, "FFFFFFFFFFFFB3B1AE3630293630299A9794FFFFFFFFFFFFFFFFFF817D793630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F236302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029423C36"
    WriteHex f, "817D79D9D8D7FFFFFFFFFFFFFFFFFF4E49433630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F236302936302974706BFFFFFFFFFFFFFFFFFFCDCBC93630293630298D8A86FFFFFFFFFFFFFFFFFFB3B1AE3630293630295B5650F2F2F2FFFFFFFFFFFFF2F2F2423C36363029363029817D79"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029D9D8D7FFFFFFFFFFFFFFFFFF74706B363029363029817D79F2F2F2FFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029"
    WriteHex f, "363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029F2F2F2FFFFFFFFFFFFFFFFFF"
    WriteHex f, "68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029817D79F2F2F2FFFFFFFFFFFFFFFFFFE6E5E4423C36363029363029F2F2F2FFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C363630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF4E4943363029423C36F2F2F2FFFFFFFFFFFF74706B363029363029817D79F2F2F2FFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFAFACE93730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFF74706B363029363029E6E5E4FFFFFFFFFFFFD9D8D7423C36363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F24E4943363029"
    WriteHex f, "3630294E49439A9794CDCBC98D8A86423C36363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630294E49433630293630294E49438D8A868D8A86423C36363029363029B3B1AEFFFFFFFFFFFFFFFFFFE6E5E4423C3636302936302968635EA7A4A1CDCBC9B3B1AE9A97949A979468635E"
    WriteHex f, "8D8A86FFFFFFFFFFFF68635E68635E363029363029423C3668635E68635E68635E68635EA7A4A1FFFFFFFFFFFF423C363630294E4943423C363630293630293630294E4943F2F2F2FFFFFF74706B363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029423C36FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFF9A97943630293630295B5650F2F2F2FFFFFFFFFFFFD9D8D7423C363630293630294E49439A9794CDCBC9B3B1AE9A9794817D79CDCBC9FFFFFFFFFFFFB3B1AE363029363029A7A4A1FFFFFFFFFFFFFFFFFFF2F2F25B5650363029363029"
    WriteHex f, "4E49439A9794CDCBC9C0BEBC74706B3630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029817D79B3B1AECDCBC9A7A4A19A97948D8A8668635EB3B1AEFFFFFFD9D8D768635E5B56503630293630294E494368635E68635E68635E"
    WriteHex f, "68635ECDCBC9FFFFFFFFFFFF9A9794363029363029363029817D79C0BEBCB3B1AE9A9794817D794E4943363029363029CDCBC9FFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFFF2F2F25B56503630293630294E49439A9794CDCBC99A9794423C3636302936302968635EFFFFFF"
    WriteHex f, "FFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A97943630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029A7A4A1FFFFFFFFFFFFF2F2F25B56503630293630294E49439A9794CDCBC9C0BEBC74706B3630293630294E4943FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5524CD0F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFF9A9794363029363029B3B1AEFFFFFFFFFFFFFFFFFFB3B1AE3630293630294E4943F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E45B56503630293630293630293630293630293630293630294E4943F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF36302936302968635ED9D8D74E4943363029"
    WriteHex f, "3630293630293630293630294E4943F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFF68635E3630293630293630293630293630293630293630293630295B5650FFFFFFFFFFFF68635E363029363029F2F2F2817D79"
    WriteHex f, "363029363029363029C0BEBCFFFFFFA7A4A1363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029E6E5E4FFFFFFFFFFFFFFFFFF68635E363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D793630293630295B5650F2F2F2FFFFFFFFFFFFD9D8D7423C36363029"
    WriteHex f, "363029363029363029363029363029363029817D79FFFFFFFFFFFFE6E5E4363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFF2F2F274706B363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE"
    WriteHex f, "36302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFF3630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFF9A97943630293630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFF"
    WriteHex f, "CDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650363029363029363029363029363029363029363029423C36E6E5E4FFFFFFFFFFFFFFFFFFCDCBC93630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C363630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFF2F2F2423C363630294E4943FFFFFFFFFFFFFFFFFFF2F2F274706B363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB5F59D3"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFCDCBC93630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFF817D7936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "A7A4A15B56503630293630293630294E49439A9794F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A8668635E68635EFFFFFFF2F2F2B3B1AE5B565036302936302974706BD9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F29A97944E49433630293630293630293630294E494368635E"
    WriteHex f, "9A9794FFFFFFFFFFFFB3B1AE68635E5B56503630293630294E494368635E68635E68635E68635EFFFFFFFFFFFFB3B1AE68635E68635ED9D8D7FFFFFFE6E5E48D8A864E49438D8A86FFFFFFD9D8D768635E68635EB3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC68635E68635ED9D8D7FFFFFF"
    WriteHex f, "FFFFFFFFFFFF8D8A86363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A8668635E68635EB3B1AEFFFFFFFFFFFFFFFFFFF2F2F29A97945B565036302936302936302936302968635E9A9794FFFFFFFFFFFFFFFFFF68635E68635E8D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9"
    WriteHex f, "74706B36302936302936302936302974706BCDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4817D79423C363630293630293630293630295B565074706BB3B1AEFFFFFFFFFFFF8D8A8668635E4E49433630293630295B565068635E68635E"
    WriteHex f, "68635E8D8A86FFFFFFFFFFFFFFFFFFFFFFFFCDCBC974706B3630293630293630293630294E494368635E817D799A9794D9D8D7FFFFFFFFFFFFFFFFFFF2F2F236302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A15B56503630293630293630294E49438D8A86F2F2F2FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFD9D8D768635E68635EB3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC9A97949A9794CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A168635E68635ED9D8D7FFFFFFFFFFFFFFFFFFFFFFFFCDCBC974706B36302936302936302936302974706BC0BEBCFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF3630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E436302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF5B5650363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFE6E5E4423C36363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFF2F2F236302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E436302936302974706BFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF8D8A86363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029423C36F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9CDCBC9D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFB3B1AE363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart4(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFC0BEBC3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A979436302936302968635EFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF817D79363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029D9D8D7FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFF2F2F236302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E3630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E468635E68635EB3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC68635E68635ECDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF4E49433630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C36363029363029C0BEBCFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFD9D8D7363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFA7A4A1363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8D7D6F4FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart5(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5BCBAED"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "5F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2B3B1AE8D8A8668635E68635E4E4943363029423C3668635E68635E68635E74706B9A9794A7A4A1CDCBC9F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC99A9794"
    WriteHex f, "74706B68635E68635E36302936302968635E68635E8D8A86B3B1AEF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart6(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C5D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D774706B363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630294E4943817D79A7A4A1E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029"
    WriteHex f, "3630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4817D79423C3636302936302936302936302936302936302936302936302936302936302936302936302974706BCDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF363029363029363029363029363029363029363029363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C36"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF9A97943630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302936302936302968635ED9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B3630293630293630293630293630293630293630293630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B565036302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "CDCBC9363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029"
    WriteHex f, "36302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC93630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630295B5650F2F2F2FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B565036302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB"
    WriteHex f, "3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "74706B363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029363029363029363029"
    WriteHex f, "36302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630295B5650F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029363029F2F2F2FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D793630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029363029363029363029D9D8D7FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F83730C8"
End Sub
Private Sub LogoPart7(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "E6E5E4363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B565036302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E3630293630293630293630293630293630293630293630293630293630293630294E4943B3B1AEE6E5E4FFFFFFFFFFFFFFFFFFFFFFFFF2F2F2CDCBC9"
    WriteHex f, "CDCBC9CDCBC99A97949A979474706B68635E4E4943817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029363029363029363029363029817D79D9D8D7FFFFFFFFFFFFCDCBC9817D79363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D793630293630293630293630293630293630293630293630293630294E4943FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF8D8A863630293630293630293630293630293630293630293630293630293630293630295B5650CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302968635EF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029"
    WriteHex f, "363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9423C363630293630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029"
    WriteHex f, "36302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E3630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029363029363029A7A4A1"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79"
    WriteHex f, "3630293630293630293630293630293630293630293630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029363029"
    WriteHex f, "3630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029"
    WriteHex f, "68635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029423C36F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029363029423C36FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B3630293630293630293630293630293630293630293630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A863630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFF363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029D9D8D7FFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029"
    WriteHex f, "68635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C36363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630293630293630293630293630293630293630293630293630298D8A86"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart8(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029A7A4A1CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9F2F2F2FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A8636302936302936302936302936302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D793630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029363029"
    WriteHex f, "74706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302968635E68635E9A9794B3B1AED9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029"
    WriteHex f, "363029363029363029363029363029363029363029423C36817D799A97948D8A86363029363029363029363029363029363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029363029363029"
    WriteHex f, "423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C3636302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029817D79"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029423C36817D79C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "68635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "68635E3630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630294E4943B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C36363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029"
    WriteHex f, "4E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B565036302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECC5F59D35F59D39591E29591E29591E29591E27A75DB5F59D3524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302968635EF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "9A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029363029363029363029"
    WriteHex f, "36302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3A29EE6CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F8AFACE9"
    WriteHex f, "8783DE453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "C0BEBC3630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630295B5650F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029"
    WriteHex f, "3630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A863630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "5F59D3AFACE9F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F8A29EE6453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C36363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "5B5650F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B3630293630293630293630293630293630293630293630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029363029363029363029363029363029"
End Sub
Private Sub LogoPart9(ByVal f As Integer)
    WriteHex f, "363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB2B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBE4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F05F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF74706B363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3E4E3F8FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F05F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029817D799A97949A97949A97949A979468635E68635E4E4943"
    WriteHex f, "3630293630293630293630293630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF363029363029363029363029363029"
    WriteHex f, "3630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE93730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFF2F2F23630293630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2B3B1AE68635E363029363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "423C36363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E3630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029"
    WriteHex f, "36302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3630293630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029423C36F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B36302936302936302936302936302936302936302936302936302974706BE6E5E4C0BEBC423C36363029363029363029363029363029363029"
    WriteHex f, "363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630293630293630293630293630293630293630293630293630294E4943F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029"
    WriteHex f, "36302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029"
    WriteHex f, "36302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFE6E5E43630293630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E3630293630293630293630293630293630293630293630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "B3B1AE363029363029363029363029363029363029363029363029363029363029F2F2F2FFFFFFB3B1AE3630293630293630293630293630293630293630293630293630293630294E4943F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029"
    WriteHex f, "3630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A8636302936302936302936302936302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029423C36E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFF817D79363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029363029363029363029363029363029363029363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029"
    WriteHex f, "36302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B56503630293630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFD9D8D73630293630293630293630293630293630293630293630293630293630295B5650F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF74706B363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFF5B56503630293630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029"
    WriteHex f, "3630293630293630293630293630294E4943F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E494336302936302936302936302936302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029"
End Sub
Private Sub LogoPart10(ByVal f As Integer)
    WriteHex f, "36302936302936302936302936302974706BF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5BCBAEDFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D793630293630293630293630293630293630293630293630293630293630295B5650F2F2F2FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFF2F2F2423C36363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E3630293630293630293630293630293630293630293630293630293630295B5650D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E43630293630293630293630293630293630293630293630293630293630293630293630294E4943C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029"
    WriteHex f, "3630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFF2F2F2423C363630293630293630293630293630293630293630293630293630293630294E4943B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFF2F2F2363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4423C36363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029423C369A9794E6E5E4FFFFFFFFFFFFF2F2F2A7A4A1423C363630293630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302936302936302936302968635EC0BEBCFFFFFFFFFFFFCDCBC9423C363630293630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "F2F2F24E4943363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC3630293630293630293630293630293630293630293630293630293630293630293630294E4943817D79"
    WriteHex f, "9A97949A97949A97944E4943363029363029363029363029363029363029363029363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029423C36F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE3630293630293630293630293630293630293630293630293630293630293630293630293630293630294E4943363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D793630293630293630293630293630293630293630293630293630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029"
    WriteHex f, "3630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302936302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B5650"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "36302936302936302936302968635EFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E4943363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F274706B363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF5B5650363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4423C36363029363029363029363029363029363029363029363029363029363029A7A4A1FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F8"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630293630293630293630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "CDCBC9363029363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D79363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
End Sub
Private Sub LogoPart11(ByVal f As Integer)
    WriteHex f, "36302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC423C36363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9A9794363029363029363029363029363029363029363029363029363029363029423C36E6E5E4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFB3B1AE423C363630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630293630295B5650F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C36363029363029363029"
    WriteHex f, "3630293630293630293630293630293630299A97945B56503630293630293630293630293630293630293630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "E4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F28D8A86363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF74706B3630293630293630293630293630293630293630293630293630293630295B5650F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E468635E363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029817D79F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D793630293630293630293630293630293630293630293630293630298D8A86FFFFFF9A9794423C36363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "3630293630295B5650FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7423C36363029363029363029363029363029363029363029363029363029363029423C36"
    WriteHex f, "D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E49A97944E4943363029363029363029363029363029363029363029363029363029363029363029363029363029423C36817D79F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F25B565036302936302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFCDCBC968635E36302936302936302936302936302936302936302936302936302936302936302936302936302968635ECDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029"
    WriteHex f, "36302936302936302936302936302936302968635EFFFFFFFFFFFFF2F2F28D8A86423C3636302936302936302936302936302936302936302936302936302974706BF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9363029363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D79A979474706B5B5650"
    WriteHex f, "363029363029363029363029363029423C3668635E8D8A86B3B1AEF2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4A7A4A174706B4E494336302936302936302936302936302968635E817D79A7A4A1E6E5E4FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFF2F2F2A7A4A168635E363029363029363029363029423C36817D79"
    WriteHex f, "CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5D7D6F4000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029363029423C36D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A86363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF74706B363029363029363029363029363029363029363029363029"
    WriteHex f, "36302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029CDCBC9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart12(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC9A97949A97949A97949A97949A97949A97949A97949A9794"
    WriteHex f, "9A97949A97949A97949A97949A97949A97949A97949A97949A97949A97949A979468635E363029363029363029363029363029363029363029363029363029363029363029363029F2F2F2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFB3B1AE363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029B3B1AEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A863630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F2F2363029363029363029363029363029363029363029363029"
    WriteHex f, "36302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302936302974706BFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD9D8D7363029363029363029363029363029363029363029363029363029363029D9D8D7FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF68635E363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF4E49433630293630293630293630293630293630293630293630293630298D8A86FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8D8A863630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C5FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029363029363029363029D9D8D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5B5650363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029423C36FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630293630293630293630293630293630293630293630293630298D8A86FFFFFF"
End Sub
Private Sub LogoPart13(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C5FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA7A4A1363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029C0BEBCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D793630293630293630293630293630293630293630293630293630294E4943FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE6E5E4363029363029363029363029363029363029"
    WriteHex f, "363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029363029817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC0BEBC363029363029363029363029363029363029363029363029363029363029D9D8D7"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C5FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF817D7968635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E68635E"
    WriteHex f, "68635E68635E68635E68635E68635E68635E817D79FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF423C363630293630293630293630293630293630293630293630293630299A9794FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart14(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFF2F1FB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart15(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D3"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB453ECC2B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart16(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5FFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F43730C82B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE93730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5D7D6F4FFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5BCBAEDFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart17(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFF2F1FB9591E23730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F07A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FBBCBAED"
    WriteHex f, "7A75DB453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED5F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D3"
    WriteHex f, "5F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D3"
    WriteHex f, "5F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D3"
    WriteHex f, "5F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D3"
    WriteHex f, "5F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D35F59D34A3CB38E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512675CC35F59D35F59D37A75DB9591E29591E29591E2"
    WriteHex f, "9591E29591E29591E29591E29591E29591E29591E29591E29591E29591E29591E29591E29591E29591E29591E27A75DB5F59D33730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A445A8E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512673F7B2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55439988E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128A452B322ABF2B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58545408E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45125439982B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart18(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5613E858E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128545402B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5322ABF8E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45124734A72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D41718E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45127443652B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5392DB88E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512392DB82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A445A8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512673F7B2B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C54D37A08E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128A452B322ABF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58545408E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45125439982B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart19(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55A3B8F"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128545402B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5322ABF8A452B8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45124734A72B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C53730C8E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "673F7B8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45127A445A2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5392DB88E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512392DB8"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C57443658E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45126D41712B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C54734A78E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128A452B"
    WriteHex f, "322ABF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C57F454E8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45125A3B8F2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart20(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55439988E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8545402B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C5D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C58A452B8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45124D37A02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB2B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5613E858E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45127A445A2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C5392DB88E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512392DB82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D41718E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45126D41712B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8D7D6F4FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C54032AF8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128A452B322ABF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A445A8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45125A3B8F2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart21(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C55439988E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128545402B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58545408E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45125439982B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C55A3B8F8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45127A445A2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D7"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5322ABF8A452B8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45124032AF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C56D41718E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45126D41712B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5392DB88E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E4512322ABF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A445A8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512613E852B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
End Sub
Private Sub LogoPart22(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "F2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C54734A78E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128545402B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58545408E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45125439982B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C5453ECCD7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55439988E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45127A445A2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5322ABF8A452B8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45124032AF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5673F7B8E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45126D41712B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5392DB88E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512322ABF2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C55F59D3F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D41718E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E4512613E852B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart23(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C54734A78E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128545402B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7E4E3F8"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57F454E8E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45125439982B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCBCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55439988E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45127F454E2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C89591E2F2F1FBFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58545408E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45124734A72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5613E858E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45126D41712B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBE4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5322ABF8E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512392DB82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBE4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D41718E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512613E852B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C88783DEE4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart24(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C54032AF8E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128A452B2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5453ECCA29EE6F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A445A8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45125439982B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C87A75DBD7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C54D37A08E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45127F454E2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DB"
    WriteHex f, "BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58545408E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45124734A72B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECC7A75DBBCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55A3B8F8E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45126D41712B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C86D67D7A29EE6D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5322ABF8A452B8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512392DB82B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D38783DEAFACE9D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5673F7B8E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512"
    WriteHex f, "8E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E45128E4512613E852B23C52B23C52B23C52B23C55F59D35F59D39591E29591E2CAC8F0E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart25(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F8524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DECAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0"
    WriteHex f, "CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0"
    WriteHex f, "CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0C7C2E65947AC4734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A7"
    WriteHex f, "4734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A74734A75547B5D7D6F4FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4524CD02B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E2"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4453ECC2B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F0453ECC"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEF2F1FBFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFF"
End Sub
Private Sub LogoPart26(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFCAC8F0453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFCAC8F0453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F0453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5453ECCD7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart27(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB6D67D72B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCD7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB6D67D72B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0E4E3F8FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart28(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "F2F1FB6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7F2F1FBFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCCAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C5D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFE4E3F85F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "9591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE63730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F85F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C53730C8AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE63730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F85F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C5453ECCCAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart29(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE63730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F85F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE63730C82B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F85F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0D7D6F4FFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart30(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7F2F1FB"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C58783DEF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB2B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart31(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F0453ECC2B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F0453ECC2B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F0"
    WriteHex f, "453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart32(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFCAC8F0453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCD7D6F4FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3"
    WriteHex f, "E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C57A75DBF2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCD7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart33(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F4CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0"
    WriteHex f, "CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0CAC8F0BCBAED453ECC2B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "3730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
End Sub
Private Sub LogoPart34(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA29EE62B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF8783DE2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F0"
End Sub
Private Sub LogoPart35(ByVal f As Integer)
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "AFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart36(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB2B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart37(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D32B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECC"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "5F59D3FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5524CD0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart38(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5CAC8F0FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C53730C8F2F1FBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C5A29EE6FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFD7D6F42B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF7A75DB2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5F59D3"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C59591E2FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE4E3F82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C5BCBAEDFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFBCBAED2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5453ECCFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF6D67D72B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C56D67D7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "453ECC2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5AFACE9FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFCAC8F02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C5E4E3F8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C55F59D3FFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
End Sub
Private Sub LogoPart39(ByVal f As Integer)
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF524CD02B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C58783DEFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "F2F1FB3730C82B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5D7D6F4FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFAFACE92B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C53730C8FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF9591E22B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C5"
    WriteHex f, "2B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C52B23C57A75DBFFFFFFFFFFFF"
    WriteHex f, "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF000000"
End Sub
